import { world, system } from "@minecraft/server";

/**
 * Menerima perintah live dari Floating Toolbox Overlay Android (/scriptevent toolbox:cmd {...})
 * dan mengeksekusinya secara instan di versi Minecraft Bedrock Play Store terbaru tanpa risiko crash offset C++.
 */
system.afterEvents.scriptEventReceive.subscribe((event) => {
    if (event.id !== "toolbox:cmd") return;

    const player = event.sourceEntity || world.getAllPlayers()[0];
    if (!player) return;

    try {
        const data = JSON.parse(event.message);
        const dim = player.dimension;

        switch (data.action) {
            case "give": {
                const itemId = data.item || "minecraft:diamond";
                const count = Math.max(1, Math.min(64, data.count || 1));
                dim.runCommandAsync(`give "${player.name}" ${itemId} ${count}`);
                player.sendMessage(`§b[Toolbox]§r Memberikan §e${count}x ${itemId}§r`);
                break;
            }

            case "gamemode": {
                const mode = data.mode || "creative";
                dim.runCommandAsync(`gamemode ${mode} "${player.name}"`);
                player.sendMessage(`§b[Toolbox]§r Gamemode diubah ke §a${mode.toUpperCase()}§r`);
                break;
            }

            case "ability": {
                const enabled = Boolean(data.enabled);
                const amp = data.amplifier || 1;
                if (data.type === "fullbright") {
                    if (enabled) {
                        dim.runCommandAsync(`effect "${player.name}" night_vision 999999 1 true`);
                    } else {
                        dim.runCommandAsync(`effect "${player.name}" night_vision 0 0 true`);
                    }
                } else if (data.type === "speed_boost") {
                    if (enabled) {
                        dim.runCommandAsync(`effect "${player.name}" speed 999999 ${amp} true`);
                    } else {
                        dim.runCommandAsync(`effect "${player.name}" speed 0 0 true`);
                    }
                } else if (data.type === "god_mode") {
                    if (enabled) {
                        dim.runCommandAsync(`effect "${player.name}" resistance 999999 255 true`);
                        dim.runCommandAsync(`effect "${player.name}" fire_resistance 999999 1 true`);
                        dim.runCommandAsync(`effect "${player.name}" saturation 999999 10 true`);
                    } else {
                        dim.runCommandAsync(`effect "${player.name}" clear`);
                    }
                } else if (data.type === "instamine") {
                    if (enabled) {
                        dim.runCommandAsync(`effect "${player.name}" haste 999999 ${amp} true`);
                    } else {
                        dim.runCommandAsync(`effect "${player.name}" haste 0 0 true`);
                    }
                }
                break;
            }

            case "environment": {
                if (data.envType === "time") {
                    dim.runCommandAsync(`time set ${data.value}`);
                } else if (data.envType === "weather") {
                    dim.runCommandAsync(`weather ${data.value}`);
                }
                break;
            }

            case "build": {
                const loc = player.location;
                const x = Math.floor(loc.x);
                const y = Math.floor(loc.y);
                const z = Math.floor(loc.z);
                const r = data.radius || 3;
                const block = data.block || "minecraft:stone_bricks";

                if (data.shape === "platform") {
                    dim.runCommandAsync(`fill ${x - r} ${y - 1} ${z - r} ${x + r} ${y - 1} ${z + r} ${block}`);
                } else if (data.shape === "walls") {
                    dim.runCommandAsync(`fill ${x - r} ${y} ${z - r} ${x + r} ${y + 3} ${z + r} ${block} outline`);
                } else if (data.shape === "clear_area") {
                    dim.runCommandAsync(`fill ${x - r} ${y} ${z - r} ${x + r} ${y + r} ${z + r} minecraft:air`);
                } else if (data.shape === "sphere") {
                    for (let dx = -r; dx <= r; dx++) {
                        for (let dy = -r; dy <= r; dy++) {
                            for (let dz = -r; dz <= r; dz++) {
                                if (dx * dx + dy * dy + dz * dz <= r * r) {
                                    dim.runCommandAsync(`setblock ${x + dx} ${y + dy} ${z + dz} ${block}`);
                                }
                            }
                        }
                    }
                }
                player.sendMessage(`§b[Toolbox Builder]§r Membangun §a${data.shape}§r dengan §e${block}§r`);
                break;
            }
        }
    } catch (err) {
        player.sendMessage(`§c[Toolbox Error]§r ${err}`);
    }
});
