effect @s resistance 999999 255 true
effect @s fire_resistance 999999 1 true
effect @s saturation 999999 10 true
