give @s netherite_sword 1
give @s netherite_pickaxe 1
give @s netherite_axe 1
give @s elytra 1
give @s firework_rocket 64
give @s enchanted_golden_apple 64
give @s totem_of_undying 5
