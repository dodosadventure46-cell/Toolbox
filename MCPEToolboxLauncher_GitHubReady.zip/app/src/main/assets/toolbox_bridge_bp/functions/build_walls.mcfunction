fill ~-4 ~ ~-4 ~4 ~3 ~4 stone_bricks outline
