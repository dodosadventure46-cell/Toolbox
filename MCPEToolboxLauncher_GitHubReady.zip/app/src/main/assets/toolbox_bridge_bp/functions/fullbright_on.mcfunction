effect @s night_vision 999999 1 true
