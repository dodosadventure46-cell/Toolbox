fill ~-4 ~-1 ~-4 ~4 ~4 ~4 glass hollow
