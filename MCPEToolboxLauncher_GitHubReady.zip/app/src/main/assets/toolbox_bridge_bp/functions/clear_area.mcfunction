fill ~-5 ~ ~-5 ~5 ~5 ~5 air
