fill ~-4 ~-1 ~-4 ~4 ~-1 ~4 stone_bricks
