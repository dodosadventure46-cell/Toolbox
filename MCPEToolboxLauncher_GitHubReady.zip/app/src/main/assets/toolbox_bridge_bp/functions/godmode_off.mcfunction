effect @s clear
