#include <jni.h>
#include <android/log.h>
#include <android/native_activity.h>
#include <dlfcn.h>
#include <string>
#include <vector>
#include <atomic>
#include <mutex>

#define LOG_TAG "ToolboxNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {
    void* g_mcpeHandle = nullptr;
    std::atomic<bool> g_fullbrightEnabled{false};
    std::atomic<float> g_zoomModifier{1.0f};
    std::atomic<float> g_gameSpeedMultiplier{1.0f};
    std::mutex g_cmdMutex;
    std::vector<std::string> g_pendingCommands;
}

typedef void (*ANativeActivity_onCreate_Func)(ANativeActivity*, void*, size_t);

extern "C" {

/**
 * Memuat pustaka native dari direktori instalasi Google Play Store (com.mojang.minecraftpe)
 * secara berurutan agar selalu kompatibel dengan versi MCPE Play Store terbaru.
 */
JNIEXPORT jboolean JNICALL
Java_com_toolbox_mcpelauncher_core_MinecraftPackageLoader_nativeLoadMinecraftLibraries(
        JNIEnv* env,
        jclass /* clazz */,
        jstring jNativeLibDir) {

    const char* nativeDir = env->GetStringUTFChars(jNativeLibDir, nullptr);
    std::string baseDir(nativeDir);
    env->ReleaseStringUTFChars(jNativeLibDir, nativeDir);

    // Urutan pemuatan dependensi wajib sebelum libminecraftpe.so
    const char* dependencyLibs[] = {
        "libc++_shared.so",
        "libfmod.so",
        "libmaesdk.so",
        "libMediaDecoders_Android.so",
        "libminecraftpe.so"
    };

    for (const char* libName : dependencyLibs) {
        std::string fullPath = baseDir + "/" + libName;
        void* handle = dlopen(fullPath.c_str(), RTLD_NOW | RTLD_GLOBAL);
        if (!handle) {
            LOGE("Gagal memuat %s (mungkin opsional di versi ini): %s", fullPath.c_str(), dlerror());
        } else {
            LOGI("Berhasil memuat pustaka: %s", fullPath.c_str());
            if (std::string(libName) == "libminecraftpe.so") {
                g_mcpeHandle = handle;
            }
        }
    }

    if (!g_mcpeHandle) {
        LOGE("KRITIS: libminecraftpe.so tidak dapat dimuat!");
        return JNI_FALSE;
    }

    // Deteksi otomatis arsitektur MCPE Play Store (1.21.80+ menggunakan GameActivity vs versi lama NativeActivity)
    void* symGameActivity = dlsym(g_mcpeHandle, "Java_com_google_androidgamesdk_GameActivity_initializeNativeCode");
    void* symNativeActivity = dlsym(g_mcpeHandle, "ANativeActivity_onCreate");

    if (symGameActivity != nullptr) {
        LOGI("Deteksi Arsitektur MCPE: Modern GameActivity (1.21.80+ / Play Store Terbaru)");
    } else if (symNativeActivity != nullptr) {
        LOGI("Deteksi Arsitektur MCPE: Legacy ANativeActivity_onCreate");
    }

    return JNI_TRUE;
}

/**
 * Mengatur status Fullbright / Gamma Override dari Floating Toolbox UI
 */
JNIEXPORT void JNICALL
Java_com_toolbox_mcpelauncher_bridge_ToolboxCommandDispatcher_nativeSetFullbright(
        JNIEnv* /* env */,
        jclass /* clazz */,
        jboolean enabled) {
    g_fullbrightEnabled.store(enabled == JNI_TRUE);
    LOGI("Toolbox Fullbright diubah ke: %s", enabled ? "ON" : "OFF");
}

/**
 * Mengatur faktor Zoom Kamera instan dari tombol cepat di layar
 */
JNIEXPORT void JNICALL
Java_com_toolbox_mcpelauncher_bridge_ToolboxCommandDispatcher_nativeSetZoomFactor(
        JNIEnv* /* env */,
        jclass /* clazz */,
        jfloat zoomFactor) {
    g_zoomModifier.store(zoomFactor);
    LOGI("Toolbox Camera Zoom diubah ke: %.2fx", zoomFactor);
}

/**
 * Menambahkan antrean perintah dari Floating UI ke antrean eksekusi in-game
 */
JNIEXPORT void JNICALL
Java_com_toolbox_mcpelauncher_bridge_ToolboxCommandDispatcher_nativeQueueToolboxCommand(
        JNIEnv* env,
        jclass /* clazz */,
        jstring jCommand) {
    const char* rawCmd = env->GetStringUTFChars(jCommand, nullptr);
    {
        std::lock_guard<std::mutex> lock(g_cmdMutex);
        g_pendingCommands.emplace_back(rawCmd);
    }
    LOGI("Perintah Toolbox masuk antrean: %s", rawCmd);
    env->ReleaseStringUTFChars(jCommand, rawCmd);
}

/**
 * Forwarder titik masuk jika dijalankan pada mode NativeActivity
 */
JNIEXPORT void ANativeActivity_onCreate(ANativeActivity* activity, void* savedState, size_t savedStateSize) {
    LOGI("ANativeActivity_onCreate dipanggil di dalam container Toolbox");
    if (g_mcpeHandle) {
        auto realOnCreate = reinterpret_cast<ANativeActivity_onCreate_Func>(
                dlsym(g_mcpeHandle, "ANativeActivity_onCreate"));
        if (realOnCreate) {
            LOGI("Meneruskan eksekusi ke ANativeActivity_onCreate milik libminecraftpe.so asli...");
            realOnCreate(activity, savedState, savedStateSize);
            return;
        }
    }
    LOGE("Simbol ANativeActivity_onCreate tidak ditemukan atau mode GameActivity sedang aktif.");
}

} // extern "C"
