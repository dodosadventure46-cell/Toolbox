package com.toolbox.mcpelauncher.automation;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;
import java.util.Random;

/**
 * Layanan Otomasi Sentuhan & Injeksi Langsung:
 * 1. Menjalankan Kill Aura / Combat Auto-Attack (5-20 CPS dengan radius sapuan sekitar crosshair)
 *    yang tetap bekerja 100% di dunia teman (Wi-Fi / Hotspot LAN) walaupun cheat mati!
 * 2. Menjalankan Auto-Inject untuk memasukkan dan mengeksekusi aksi Toolbox secara otomatis
 *    tanpa pengguna perlu mengetik atau paste manual.
 */
public class ToolboxAutoService extends AccessibilityService {
    private static final String TAG = "ToolboxAutoService";
    private static volatile ToolboxAutoService sInstance;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();

    private volatile boolean isKillAuraActive = false;
    private volatile int auraCps = 12;
    private volatile int auraSweepRadiusPx = 65;

    public static ToolboxAutoService getInstance() {
        return sInstance;
    }

    public static boolean isServiceConnected() {
        return sInstance != null;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        sInstance = this;
        Log.i(TAG, "ToolboxAutoService aktif dan siap untuk Combat Aura & Direct Injection!");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
        isKillAuraActive = false;
    }

    @Override
    public void onDestroy() {
        isKillAuraActive = false;
        if (sInstance == this) {
            sInstance = null;
        }
        super.onDestroy();
    }

    public void setKillAuraEnabled(boolean enabled) {
        if (this.isKillAuraActive == enabled) return;
        this.isKillAuraActive = enabled;
        if (enabled) {
            scheduleNextAuraStrike();
        }
    }

    public boolean isKillAuraEnabled() {
        return isKillAuraActive;
    }

    public void setAuraConfig(int cps, int sweepRadiusPx) {
        this.auraCps = Math.max(4, Math.min(20, cps));
        this.auraSweepRadiusPx = Math.max(10, Math.min(220, sweepRadiusPx));
    }

    public int getAuraCps() {
        return auraCps;
    }

    private void scheduleNextAuraStrike() {
        if (!isKillAuraActive) return;
        long delayMs = Math.max(45L, 1000L / Math.max(1, auraCps));
        handler.postDelayed(() -> {
            if (!isKillAuraActive) return;
            performAuraStrikeGesture();
            scheduleNextAuraStrike();
        }, delayMs);
    }

    /**
     * Melakukan serangan cepat (Multi-Target Sweep Tap) di sekitar titik tengah layar
     * untuk mengenai target/musuh di dunia Wi-Fi / Hotspot LAN tanpa perlu akses cheat.
     */
    private void performAuraStrikeGesture() {
        try {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            int screenW = Math.max(dm.widthPixels, dm.heightPixels);
            int screenH = Math.min(dm.widthPixels, dm.heightPixels);

            int centerX = screenW / 2;
            int centerY = screenH / 2;

            // Variasi sudut sapuan (sweep) di sekitar crosshair agar mengenai entitas yang bergerak
            int offsetX = random.nextInt(auraSweepRadiusPx * 2 + 1) - auraSweepRadiusPx;
            int offsetY = random.nextInt(auraSweepRadiusPx + 1) - (auraSweepRadiusPx / 2);

            float targetX = Math.max(100, Math.min(screenW - 100, centerX + offsetX));
            float targetY = Math.max(100, Math.min(screenH - 100, centerY + offsetY));

            Path tapPath = new Path();
            tapPath.moveTo(targetX, targetY);

            GestureDescription.Builder builder = new GestureDescription.Builder();
            builder.addStroke(new GestureDescription.StrokeDescription(tapPath, 0, 22));
            dispatchGesture(builder.build(), null, null);
        } catch (Exception e) {
            Log.w(TAG, "Aura strike error: " + e.getMessage());
        }
    }

    /**
     * Menginjeksikan perintah secara otomatis ke dalam layar game jika WebSocket belum terhubung.
     */
    public void autoInjectCommandIntoGame(final String commandToRun) {
        handler.postDelayed(() -> {
            try {
                DisplayMetrics dm = getResources().getDisplayMetrics();
                int w = Math.max(dm.widthPixels, dm.heightPixels);
                int h = Math.min(dm.widthPixels, dm.heightPixels);

                // Langkah 1: Ketuk ikon Chat di bar atas tengah MCPE
                performTap(w * 0.48f, h * 0.055f);

                // Langkah 2: Isi teks langsung ke node EditText milik MCPE dan tekan tombol Kirim
                handler.postDelayed(() -> {
                    boolean filled = fillActiveEditTextNode(commandToRun);
                    if (filled) {
                        handler.postDelayed(() -> performTap(w * 0.95f, h * 0.92f), 180);
                    }
                }, 380);
            } catch (Exception e) {
                Log.w(TAG, "Auto-inject gagal: " + e.getMessage());
            }
        }, 120);
    }

    private boolean fillActiveEditTextNode(String text) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        return searchAndFillEditText(root, text);
    }

    private boolean searchAndFillEditText(AccessibilityNodeInfo node, String text) {
        if (node == null) return false;
        CharSequence cls = node.getClassName();
        if (cls != null && (cls.toString().contains("EditText") || node.isEditable())) {
            Bundle args = new Bundle();
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            boolean ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
            if (ok) return true;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            if (searchAndFillEditText(node.getChild(i), text)) {
                return true;
            }
        }
        return false;
    }

    private void performTap(float x, float y) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(p, 0, 35));
        dispatchGesture(b.build(), null, null);
    }
}
