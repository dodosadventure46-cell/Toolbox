package com.toolbox.mcpelauncher.bridge;

import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Memodifikasi file biner NBT level.dat milik dunia Minecraft secara langsung
 * untuk membuka kunci Cheat (commandsEnabled = 1) dan mengubah GameType (Survival/Creative)
 * walaupun dunia dibuat tanpa mengaktifkan Cheat!
 */
public class LevelDatPatcher {
    private static final String TAG = "LevelDatPatcher";

    public static int forceUnlockCheatsInAllLocalWorlds(int targetGameType) {
        int patchedCount = 0;
        List<File> worldDirs = findLocalWorldDirectories();
        for (File worldDir : worldDirs) {
            File levelDat = new File(worldDir, "level.dat");
            if (levelDat.exists() && levelDat.canRead() && levelDat.canWrite()) {
                if (patchSingleLevelDat(levelDat, targetGameType)) {
                    patchedCount++;
                }
            }
        }
        return patchedCount;
    }

    private static List<File> findLocalWorldDirectories() {
        List<File> results = new ArrayList<>();
        File extRoot = Environment.getExternalStorageDirectory();
        String[] candidatePaths = {
            "games/com.mojang/minecraftWorlds",
            "Android/data/com.mojang.minecraftpe/files/games/com.mojang/minecraftWorlds"
        };
        for (String rel : candidatePaths) {
            File base = new File(extRoot, rel);
            if (base.exists() && base.isDirectory()) {
                File[] children = base.listFiles();
                if (children != null) {
                    for (File child : children) {
                        if (child.isDirectory()) {
                            results.add(child);
                        }
                    }
                }
            }
        }
        return results;
    }

    private static boolean patchSingleLevelDat(File levelDatFile, int targetGameType) {
        try {
            byte[] data;
            try (FileInputStream fis = new FileInputStream(levelDatFile)) {
                data = new byte[(int) levelDatFile.length()];
                int read = fis.read(data);
                if (read <= 16) return false;
            }

            boolean modified = false;

            // 1. Cari tag NBT Byte (0x01) bernama "commandsEnabled" lalu ubah nilainya menjadi 1 (ON)
            byte[] cmdTag = createNbtNamedHeader((byte) 1, "commandsEnabled");
            int idxCmd = indexOfBytes(data, cmdTag);
            if (idxCmd != -1 && idxCmd + cmdTag.length < data.length) {
                data[idxCmd + cmdTag.length] = (byte) 1;
                modified = true;
            }

            // 2. Jika diminta mengubah GameType (0 = Survival, 1 = Creative), ubah tag NBT Int (0x03) "GameType"
            if (targetGameType >= 0) {
                byte[] gmTag = createNbtNamedHeader((byte) 3, "GameType");
                int idxGm = indexOfBytes(data, gmTag);
                if (idxGm != -1 && idxGm + gmTag.length + 4 <= data.length) {
                    int valPos = idxGm + gmTag.length;
                    data[valPos] = (byte) (targetGameType & 0xFF);
                    data[valPos + 1] = 0;
                    data[valPos + 2] = 0;
                    data[valPos + 3] = 0;
                    modified = true;
                }
            }

            if (modified) {
                try (FileOutputStream fos = new FileOutputStream(levelDatFile, false)) {
                    fos.write(data);
                }
                Log.i(TAG, "Berhasil membuka kunci level.dat: " + levelDatFile.getAbsolutePath());
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Gagal memodifikasi level.dat", e);
        }
        return false;
    }

    private static byte[] createNbtNamedHeader(byte tagType, String name) {
        byte[] nameBytes = name.getBytes(StandardCharsets.UTF_8);
        int len = nameBytes.length;
        byte[] header = new byte[1 + 2 + len];
        header[0] = tagType;
        header[1] = (byte) (len & 0xFF);
        header[2] = (byte) ((len >> 8) & 0xFF);
        System.arraycopy(nameBytes, 0, header, 3, len);
        return header;
    }

    private static int indexOfBytes(byte[] source, byte[] target) {
        outer:
        for (int i = 0; i <= source.length - target.length; i++) {
            for (int j = 0; j < target.length; j++) {
                if (source[i + j] != target[j]) continue outer;
            }
            return i;
        }
        return -1;
    }
}
