package com.toolbox.mcpelauncher.overlay;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;

import com.toolbox.mcpelauncher.bridge.ToolboxWebSocketServer;

public class ToolboxFloatingService extends Service {
    private static final String TAG = "ToolboxFloatingService";
    private ToolboxOverlayManager overlayManager;

    @Override
    public void onCreate() {
        super.onCreate();
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izin Tampilkan di Atas Aplikasi Lain belum aktif!", Toast.LENGTH_LONG).show();
            stopSelf();
            return;
        }
        try {
            ToolboxWebSocketServer.getInstance().startServer();
            overlayManager = new ToolboxOverlayManager(this, this::stopSelf);
            overlayManager.showOverlayWindows();
            Log.i(TAG, "ToolboxFloatingService v3.0 berhasil dijalankan!");
        } catch (Exception e) {
            Log.e(TAG, "Gagal menampilkan overlay", e);
            stopSelf();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        ToolboxWebSocketServer.getInstance().startServer();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (overlayManager != null) {
            overlayManager.removeAllOverlayWindows();
            overlayManager = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
