package com.toolbox.mcpelauncher.overlay;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;

/**
 * Service yang menjaga tombol mengambang (🛠️ TB), HUD FPS, Crosshair, dan Menu 4-Tab Toolbox
 * tetap tampil di atas layar saat aplikasi Minecraft Bedrock (com.mojang.minecraftpe) berjalan.
 */
public class ToolboxFloatingService extends Service {
    private static final String TAG = "ToolboxFloatingService";
    private ToolboxOverlayManager overlayManager;

    @Override
    public void onCreate() {
        super.onCreate();
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izin Tampilkan di Atas Aplikasi Lain belum aktif!", Toast.LENGTH_LONG).show();
            stopSelf();
            return;
        }
        try {
            overlayManager = new ToolboxOverlayManager(this, this::stopSelf);
            overlayManager.showOverlayWindows();
            Log.i(TAG, "ToolboxFloatingService berhasil ditampilkan di atas layar!");
        } catch (Exception e) {
            Log.e(TAG, "Gagal menampilkan overlay", e);
            stopSelf();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (overlayManager != null) {
            overlayManager.removeAllOverlayWindows();
            overlayManager = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
