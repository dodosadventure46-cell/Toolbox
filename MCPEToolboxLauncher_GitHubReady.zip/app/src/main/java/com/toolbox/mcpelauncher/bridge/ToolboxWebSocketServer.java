package com.toolbox.mcpelauncher.bridge;

import android.util.Base64;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Server WebSocket Lokal (127.0.0.1:19131) yang berbicara langsung dengan protokol
 * internal Minecraft Bedrock (commandRequest v1).
 * Saat terhubung, klik tombol di Toolbox langsung memberi item / mengubah dunia secara instan
 * di latar belakang TANPA membuka kolom chat sama sekali!
 */
public class ToolboxWebSocketServer {
    private static final String TAG = "ToolboxWSServer";
    public static final int PORT = 19131;
    private static final String WS_MAGIC_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

    private static ToolboxWebSocketServer sInstance;
    private ServerSocket serverSocket;
    private volatile boolean isRunning = false;
    private final CopyOnWriteArrayList<OutputStream> activeClients = new CopyOnWriteArrayList<>();
    private final ExecutorService executor = Executors.newCachedThreadPool();

    public static synchronized ToolboxWebSocketServer getInstance() {
        if (sInstance == null) {
            sInstance = new ToolboxWebSocketServer();
        }
        return sInstance;
    }

    public synchronized void startServer() {
        if (isRunning) return;
        isRunning = true;
        executor.execute(() -> {
            try {
                serverSocket = new ServerSocket(PORT, 8, InetAddress.getByName("127.0.0.1"));
                Log.i(TAG, "Toolbox Direct Engine Server aktif di ws://127.0.0.1:" + PORT);
                while (isRunning && !serverSocket.isClosed()) {
                    Socket client = serverSocket.accept();
                    executor.execute(() -> handleClient(client));
                }
            } catch (Exception e) {
                Log.e(TAG, "WebSocket server berhenti: " + e.getMessage());
            } finally {
                isRunning = false;
            }
        });
    }

    public boolean hasConnectedGameEngine() {
        return !activeClients.isEmpty();
    }

    /**
     * Mengirimkan paket JSON commandRequest langsung ke engine Minecraft yang terhubung.
     */
    public boolean sendDirectEngineAction(String rawCommand) {
        if (activeClients.isEmpty()) return false;
        String cleanCmd = rawCommand.startsWith("/") ? rawCommand.substring(1) : rawCommand;
        String escapedCmd = cleanCmd.replace("\\", "\\\\").replace("\"", "\\\"");
        String reqId = UUID.randomUUID().toString();

        String jsonPacket = "{"
                + "\"header\":{"
                + "\"version\":1,"
                + "\"requestId\":\"" + reqId + "\","
                + "\"messagePurpose\":\"commandRequest\","
                + "\"messageType\":\"commandRequest\""
                + "},"
                + "\"body\":{"
                + "\"version\":1,"
                + "\"commandLine\":\"" + escapedCmd + "\","
                + "\"origin\":{\"type\":\"player\"}"
                + "}"
                + "}";

        byte[] frame = encodeWebSocketTextFrame(jsonPacket);
        boolean sentAny = false;
        for (OutputStream out : activeClients) {
            try {
                synchronized (out) {
                    out.write(frame);
                    out.flush();
                }
                sentAny = true;
            } catch (Exception e) {
                activeClients.remove(out);
            }
        }
        return sentAny;
    }

    private void handleClient(Socket socket) {
        OutputStream out = null;
        try {
            InputStream in = socket.getInputStream();
            out = socket.getOutputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));

            String line;
            String webSocketKey = null;
            while ((line = reader.readLine()) != null && !line.isEmpty()) {
                if (line.toLowerCase().startsWith("sec-websocket-key:")) {
                    webSocketKey = line.substring(18).trim();
                }
            }

            if (webSocketKey == null) {
                socket.close();
                return;
            }

            MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
            byte[] acceptRaw = sha1.digest((webSocketKey + WS_MAGIC_GUID).getBytes(StandardCharsets.UTF_8));
            String acceptKey = Base64.encodeToString(acceptRaw, Base64.NO_WRAP);

            String handshakeResponse = "HTTP/1.1 101 Switching Protocols\r\n"
                    + "Upgrade: websocket\r\n"
                    + "Connection: Upgrade\r\n"
                    + "Sec-WebSocket-Accept: " + acceptKey + "\r\n\r\n";
            out.write(handshakeResponse.getBytes(StandardCharsets.UTF_8));
            out.flush();

            activeClients.add(out);
            Log.i(TAG, "Mesin Minecraft Bedrock berhasil terhubung ke Toolbox Direct Engine!");

            // Kirim notifikasi langsung di layar game bahwa Direct Engine aktif
            sendDirectEngineAction("title @s actionbar §b§l[Toolbox Direct Engine Terhubung!]");

            byte[] buffer = new byte[2048];
            while (isRunning && !socket.isClosed()) {
                int r = in.read(buffer);
                if (r == -1) break;
            }
        } catch (Exception e) {
            Log.w(TAG, "Koneksi engine terputus: " + e.getMessage());
        } finally {
            if (out != null) activeClients.remove(out);
            try { socket.close(); } catch (Exception ignored) {}
        }
    }

    private byte[] encodeWebSocketTextFrame(String text) {
        byte[] payload = text.getBytes(StandardCharsets.UTF_8);
        int len = payload.length;
        byte[] frame;
        if (len <= 125) {
            frame = new byte[2 + len];
            frame[0] = (byte) 0x81;
            frame[1] = (byte) len;
            System.arraycopy(payload, 0, frame, 2, len);
        } else {
            frame = new byte[4 + len];
            frame[0] = (byte) 0x81;
            frame[1] = (byte) 126;
            frame[2] = (byte) ((len >> 8) & 0xFF);
            frame[3] = (byte) (len & 0xFF);
            System.arraycopy(payload, 0, frame, 4, len);
        }
        return frame;
    }
}
