package com.toolbox.mcpelauncher.core;

import android.view.Choreographer;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * 1. Menghitung True FPS, Rata-rata Frame-Time (ms), dan 1% Low FPS berdasarkan distribusi
 *    interval render aktual serta beban jadwal frame (bukan sekadar angka 60 statis).
 * 2. Memindai jaringan Wi-Fi / Hotspot lokal menggunakan protokol UDP RakNet Unconnected Ping (Port 19132)
 *    untuk mendeteksi dunia teman (Nama World, IP Host, Jumlah Pemain, dan Ping ms Real-Time).
 */
public class TrueFpsAndLanScanner {

    public interface TelemetryListener {
        void onTelemetryUpdated(int realFps, float avgFrameMs, int onePercentLowFps, String lanStatusText);
    }

    private static final byte[] RAKNET_MAGIC = new byte[]{
        (byte) 0x00, (byte) 0xff, (byte) 0xff, (byte) 0x00,
        (byte) 0xfe, (byte) 0xfe, (byte) 0xfe, (byte) 0xfe,
        (byte) 0xfd, (byte) 0xfd, (byte) 0xfd, (byte) 0xfd,
        (byte) 0x12, (byte) 0x34, (byte) 0x56, (byte) 0x78
    };

    private final TelemetryListener listener;
    private final ScheduledExecutorService lanExecutor = Executors.newSingleThreadScheduledExecutor();
    private volatile boolean isRunning = false;

    private long lastFrameNanos = 0;
    private final float[] frameIntervalsMs = new float[120];
    private int sampleIndex = 0;
    private int sampleCount = 0;
    private long lastReportTimeMs = 0;

    private volatile String latestLanInfo = "📡 Wi-Fi/Hotspot: Memindai port 19132...";

    public TrueFpsAndLanScanner(TelemetryListener listener) {
        this.listener = listener;
    }

    public void start() {
        if (isRunning) return;
        isRunning = true;
        startFrameAnalyzer();
        lanExecutor.scheduleWithFixedDelay(this::probeLocalWifiAndHotspotWorlds, 0, 3, TimeUnit.SECONDS);
    }

    public void stop() {
        isRunning = false;
        lanExecutor.shutdownNow();
    }

    private void startFrameAnalyzer() {
        Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() {
            @Override
            public void doFrame(long frameTimeNanos) {
                if (!isRunning) return;

                long nowNanos = System.nanoTime();
                if (lastFrameNanos != 0) {
                    // Gabungkan delta vsync dan jitter eksekusi aktual di thread render
                    long renderDeltaNanos = nowNanos - lastFrameNanos;
                    float deltaMs = renderDeltaNanos / 1_000_000.0f;
                    if (deltaMs > 1.0f && deltaMs < 500.0f) {
                        frameIntervalsMs[sampleIndex] = deltaMs;
                        sampleIndex = (sampleIndex + 1) % frameIntervalsMs.length;
                        if (sampleCount < frameIntervalsMs.length) {
                            sampleCount++;
                        }
                    }
                }
                lastFrameNanos = nowNanos;

                long nowMs = System.currentTimeMillis();
                if (nowMs - lastReportTimeMs >= 500 && sampleCount > 4) {
                    lastReportTimeMs = nowMs;
                    computeAndEmitMetrics();
                }

                Choreographer.getInstance().postFrameCallback(this);
            }
        });
    }

    private void computeAndEmitMetrics() {
        float sumMs = 0f;
        float worstFrameMs = 0f;
        for (int i = 0; i < sampleCount; i++) {
            float ms = frameIntervalsMs[i];
            sumMs += ms;
            if (ms > worstFrameMs) {
                worstFrameMs = ms;
            }
        }
        float avgMs = sumMs / sampleCount;
        int realFps = Math.max(1, Math.round(1000.0f / avgMs));
        int onePercentLow = Math.max(1, Math.round(1000.0f / Math.max(avgMs, worstFrameMs)));

        if (listener != null) {
            listener.onTelemetryUpdated(realFps, avgMs, onePercentLow, latestLanInfo);
        }
    }

    /**
     * Mengirim paket RakNet Unconnected Ping (0x01) ke 255.255.255.255:19132
     * untuk mendeteksi dunia Minecraft teman di jaringan Wi-Fi / Hotspot yang sama.
     */
    private void probeLocalWifiAndHotspotWorlds() {
        try (DatagramSocket socket = new DatagramSocket()) {
            socket.setBroadcast(true);
            socket.setSoTimeout(1200);

            ByteBuffer buf = ByteBuffer.allocate(33);
            buf.put((byte) 0x01); // ID_UNCONNECTED_PING
            buf.putLong(System.currentTimeMillis());
            buf.put(RAKNET_MAGIC);
            buf.putLong(2L);

            byte[] payload = buf.array();
            long sendTime = System.currentTimeMillis();

            DatagramPacket packet = new DatagramPacket(
                    payload,
                    payload.length,
                    InetAddress.getByName("255.255.255.255"),
                    19132
            );
            socket.send(packet);

            byte[] recvBuf = new byte[1024];
            DatagramPacket recvPacket = new DatagramPacket(recvBuf, recvBuf.length);
            socket.receive(recvPacket);

            long pingMs = Math.max(1, System.currentTimeMillis() - sendTime);
            String hostIp = recvPacket.getAddress().getHostAddress();

            if (recvPacket.getLength() > 35 && recvBuf[0] == (byte) 0x1C) {
                int strLen = ((recvBuf[33] & 0xFF) << 8) | (recvBuf[34] & 0xFF);
                if (strLen > 0 && 35 + strLen <= recvPacket.getLength()) {
                    String motdRaw = new String(recvBuf, 35, strLen, StandardCharsets.UTF_8);
                    String[] parts = motdRaw.split(";");
                    if (parts.length >= 6) {
                        String worldTitle = parts[1];
                        String version = parts[3];
                        String players = parts[4] + "/" + parts[5];
                        latestLanInfo = "📶 LAN Teman: " + worldTitle + " (" + players + " pemain, v" + version + ") | IP: " + hostIp + " | Ping: " + pingMs + " ms";
                        return;
                    }
                }
            }
            latestLanInfo = "📶 LAN Host Terdeteksi di " + hostIp + ":19132 | Ping: " + pingMs + " ms";
        } catch (Exception e) {
            latestLanInfo = "📡 Wi-Fi/Hotspot: Siap memindai dunia teman (Port 19132)";
        }
    }
}
