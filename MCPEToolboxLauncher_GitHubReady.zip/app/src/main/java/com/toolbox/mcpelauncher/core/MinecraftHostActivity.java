package com.toolbox.mcpelauncher.core;

import android.app.Activity;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Toast;

import com.toolbox.mcpelauncher.overlay.ToolboxOverlayManager;

public class MinecraftHostActivity extends Activity {
    private static final String TAG = "MinecraftHostActivity";

    private MinecraftPackageLoader.LoadedMinecraftEnv mcEnv;
    private ToolboxOverlayManager overlayManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        try {
            mcEnv = MinecraftPackageLoader.prepareMinecraftEnvironment(this);

            overlayManager = new ToolboxOverlayManager(this);
            overlayManager.attachToActivityWindow();

            Toast.makeText(
                    this,
                    "MCPE " + mcEnv.versionName + " dimuat bersama Toolbox Overlay!",
                    Toast.LENGTH_LONG
            ).show();

        } catch (Exception e) {
            Log.e(TAG, "Gagal menyiapkan container Minecraft", e);
            Toast.makeText(this, "Error memuat MCPE: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override
    public ClassLoader getClassLoader() {
        if (mcEnv != null && mcEnv.classLoader != null) {
            return mcEnv.classLoader;
        }
        return super.getClassLoader();
    }

    @Override
    public AssetManager getAssets() {
        if (mcEnv != null && mcEnv.assetManager != null) {
            return mcEnv.assetManager;
        }
        return super.getAssets();
    }

    @Override
    public Resources getResources() {
        if (mcEnv != null && mcEnv.resources != null) {
            return mcEnv.resources;
        }
        return super.getResources();
    }
}
