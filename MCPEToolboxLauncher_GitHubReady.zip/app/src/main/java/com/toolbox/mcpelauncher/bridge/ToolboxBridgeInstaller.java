package com.toolbox.mcpelauncher.bridge;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ToolboxBridgeInstaller {
    private static final String TAG = "ToolboxBridgeInstaller";

    private static final String[] ASSET_FILES = {
        "manifest.json",
        "functions/kit_netherite.mcfunction",
        "functions/fullbright_on.mcfunction",
        "functions/fullbright_off.mcfunction",
        "functions/godmode_on.mcfunction",
        "functions/godmode_off.mcfunction",
        "functions/build_platform.mcfunction",
        "functions/build_walls.mcfunction",
        "functions/build_dome.mcfunction",
        "functions/clear_area.mcfunction"
    };

    public static boolean installOrUpdateBridgePack(Context context) {
        try {
            // 1. Salin ke folder games/com.mojang/development_behavior_packs jika diizinkan
            File extDir = new File(
                    Environment.getExternalStorageDirectory(),
                    "games/com.mojang/development_behavior_packs/MCPEToolboxBridge_BP"
            );
            copyPackToDirectory(context.getAssets(), extDir);
        } catch (Exception ignored) {
        }

        try {
            // 2. Buat juga di folder Download sebagai file MCPEToolboxBridge.mcpack agar bisa diklik 1x di File Manager
            File downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (!downloadDir.exists()) {
                downloadDir = context.getExternalFilesDir(null);
            }
            File mcpackFile = new File(downloadDir, "MCPEToolboxBridge.mcpack");
            createMcpackZip(context.getAssets(), mcpackFile);
            Log.i(TAG, "File .mcpack berhasil dibuat di: " + mcpackFile.getAbsolutePath());
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Gagal membuat MCPEToolboxBridge.mcpack", e);
            return false;
        }
    }

    private static void copyPackToDirectory(AssetManager assets, File targetDir) throws IOException {
        for (String relPath : ASSET_FILES) {
            File outFile = new File(targetDir, relPath);
            File parent = outFile.getParentFile();
            if (parent != null && !parent.exists()) {
                parent.mkdirs();
            }
            try (InputStream in = assets.open("toolbox_bridge_bp/" + relPath);
                 FileOutputStream out = new FileOutputStream(outFile)) {
                byte[] buf = new byte[4096];
                int len;
                while ((len = in.read(buf)) != -1) {
                    out.write(buf, 0, len);
                }
            }
        }
    }

    private static void createMcpackZip(AssetManager assets, File outZipFile) throws IOException {
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(outZipFile))) {
            for (String relPath : ASSET_FILES) {
                zos.putNextEntry(new ZipEntry(relPath));
                try (InputStream in = assets.open("toolbox_bridge_bp/" + relPath)) {
                    byte[] buf = new byte[4096];
                    int len;
                    while ((len = in.read(buf)) != -1) {
                        zos.write(buf, 0, len);
                    }
                }
                zos.closeEntry();
            }
        }
    }

    public static void writeCommandStateFile(Context context, String commandText) {
        File cmdFile = new File(context.getExternalFilesDir(null), "toolbox_last_command.txt");
        try (FileOutputStream fos = new FileOutputStream(cmdFile, false)) {
            fos.write(commandText.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            Log.e(TAG, "Gagal menulis command state", e);
        }
    }
}
