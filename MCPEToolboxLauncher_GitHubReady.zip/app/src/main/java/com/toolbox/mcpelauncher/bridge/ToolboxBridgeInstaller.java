package com.toolbox.mcpelauncher.bridge;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Memasang Add-On Jembatan Script API (@minecraft/server) secara otomatis.
 * Dengan metode hibrida ini, fitur Give Item, Rapid Builder, Teleport, Weather, dan Fullbright
 * TIDAK AKAN RUSAK meskipun Minecraft di-update otomatis oleh Google Play Store ke versi baru!
 */
public class ToolboxBridgeInstaller {
    private static final String TAG = "ToolboxBridgeInstaller";

    public static File getDevelopmentBehaviorPacksDir() {
        return new File(
                Environment.getExternalStorageDirectory(),
                "games/com.mojang/development_behavior_packs/MCPEToolboxBridge_BP"
        );
    }

    public static boolean installOrUpdateBridgePack(Context context) {
        try {
            File targetDir = getDevelopmentBehaviorPacksDir();
            File scriptsDir = new File(targetDir, "scripts");
            if (!scriptsDir.exists() && !scriptsDir.mkdirs()) {
                Log.w(TAG, "Membuat direktori di internal app storage sebagai cadangan...");
                targetDir = new File(context.getExternalFilesDir(null), "MCPEToolboxBridge_BP");
                scriptsDir = new File(targetDir, "scripts");
                scriptsDir.mkdirs();
            }

            copyAssetFile(context.getAssets(), "toolbox_bridge_bp/manifest.json", new File(targetDir, "manifest.json"));
            copyAssetFile(context.getAssets(), "toolbox_bridge_bp/scripts/main.js", new File(scriptsDir, "main.js"));

            Log.i(TAG, "Toolbox Script API Bridge berhasil dipasang di: " + targetDir.getAbsolutePath());
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Gagal memasang Toolbox Bridge Pack", e);
            return false;
        }
    }

    /**
     * Menulis payload aksi dari Floating UI Android ke file state jembatan / antrean perintah
     */
    public static void writeCommandStateFile(Context context, String jsonPayload) {
        File cmdFile = new File(context.getExternalFilesDir(null), "toolbox_live_command.json");
        try (FileOutputStream fos = new FileOutputStream(cmdFile, false)) {
            fos.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            Log.e(TAG, "Gagal menulis state perintah", e);
        }
    }

    private static void copyAssetFile(AssetManager assets, String assetPath, File outFile) throws IOException {
        try (InputStream in = assets.open(assetPath);
             FileOutputStream out = new FileOutputStream(outFile)) {
            byte[] buffer = new byte[4096];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
        }
    }
}
