package com.toolbox.mcpelauncher.overlay;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.toolbox.mcpelauncher.bridge.ToolboxCommandDispatcher;

public class ToolboxOverlayManager {

    private final Activity activity;
    private FrameLayout rootOverlayContainer;
    private TextView hudTextView;
    private View mainPanelWindow;

    private boolean isMenuOpen = false;
    private boolean isFullbright = false;
    private boolean isFlySpeedBoost = false;
    private boolean isGodMode = false;
    private boolean isZoomActive = false;
    private int currentSpeedAmplifier = 2;
    private String selectedBuildBlock = "minecraft:stone_bricks";
    private int buildRadius = 4;

    private long lastFrameTimeNanos = 0;
    private int frameCount = 0;
    private int currentFps = 60;

    public ToolboxOverlayManager(Activity activity) {
        this.activity = activity;
    }

    public void attachToActivityWindow() {
        ViewGroup decorView = (ViewGroup) activity.getWindow().getDecorView();
        rootOverlayContainer = new FrameLayout(activity);
        FrameLayout.LayoutParams rootParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        );
        rootOverlayContainer.setLayoutParams(rootParams);

        hudTextView = createHudIndicator();
        rootOverlayContainer.addView(hudTextView);

        View floatingToggleBtn = createDraggableFloatingButton();
        rootOverlayContainer.addView(floatingToggleBtn);

        View quickZoomBtn = createQuickZoomButton();
        rootOverlayContainer.addView(quickZoomBtn);

        mainPanelWindow = createMainToolboxPanel();
        mainPanelWindow.setVisibility(View.GONE);
        rootOverlayContainer.addView(mainPanelWindow);

        decorView.addView(rootOverlayContainer);
        startFpsCounter();
    }

    private TextView createHudIndicator() {
        TextView tv = new TextView(activity);
        tv.setTextColor(Color.parseColor("#E0F2FE"));
        tv.setTextSize(12f);
        tv.setPadding(24, 14, 24, 14);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#990F172A"));
        bg.setCornerRadius(16f);
        bg.setStroke(2, Color.parseColor("#38BDF8"));
        tv.setBackground(bg);

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.setMargins(28, 24, 0, 0);
        tv.setLayoutParams(params);
        updateHudText();
        return tv;
    }

    private void updateHudText() {
        if (hudTextView == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("⚡ FPS: ").append(currentFps);
        if (isFullbright) sb.append(" | ☀️ Fullbright");
        if (isFlySpeedBoost) sb.append(" | 🚀 Speed x").append(currentSpeedAmplifier);
        if (isGodMode) sb.append(" | 🛡️ GodMode");
        if (isZoomActive) sb.append(" | 🔍 Zoom 4x");
        hudTextView.setText(sb.toString());
    }

    private View createDraggableFloatingButton() {
        Button btn = new Button(activity);
        btn.setText("🛠️ TB");
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(13f);
        btn.setAllCaps(false);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#DD0284C7"));
        bg.setCornerRadius(100f);
        bg.setStroke(3, Color.parseColor("#7DD3FC"));
        btn.setBackground(bg);

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(144, 144);
        params.gravity = Gravity.TOP | Gravity.START;
        params.leftMargin = 32;
        params.topMargin = 136;
        btn.setLayoutParams(params);

        btn.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            private boolean isDragged = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) v.getLayoutParams();
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = lp.leftMargin;
                        initialY = lp.topMargin;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        isDragged = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - initialTouchX);
                        int dy = (int) (event.getRawY() - initialTouchY);
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            isDragged = true;
                            lp.leftMargin = Math.max(0, initialX + dx);
                            lp.topMargin = Math.max(0, initialY + dy);
                            v.setLayoutParams(lp);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!isDragged) {
                            toggleMainPanel();
                        }
                        return true;
                }
                return false;
            }
        });

        return btn;
    }

    private View createQuickZoomButton() {
        Button zoomBtn = new Button(activity);
        zoomBtn.setText("🔍");
        zoomBtn.setTextSize(16f);
        zoomBtn.setTextColor(Color.WHITE);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#AA1E293B"));
        bg.setCornerRadius(100f);
        bg.setStroke(2, Color.parseColor("#94A3B8"));
        zoomBtn.setBackground(bg);

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(120, 120);
        params.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
        params.rightMargin = 32;
        zoomBtn.setLayoutParams(params);

        zoomBtn.setOnClickListener(v -> {
            isZoomActive = !isZoomActive;
            ToolboxCommandDispatcher.safeSetZoomFactor(isZoomActive ? 4.0f : 1.0f);
            bg.setColor(Color.parseColor(isZoomActive ? "#DD0284C7" : "#AA1E293B"));
            updateHudText();
        });
        return zoomBtn;
    }

    private void toggleMainPanel() {
        isMenuOpen = !isMenuOpen;
        mainPanelWindow.setVisibility(isMenuOpen ? View.VISIBLE : View.GONE);
    }

    private View createMainToolboxPanel() {
        DisplayMetrics dm = activity.getResources().getDisplayMetrics();
        int panelWidth = (int) (dm.widthPixels * 0.80f);
        int panelHeight = (int) (dm.heightPixels * 0.82f);

        LinearLayout card = new LinearLayout(activity);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(32, 24, 32, 24);

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.parseColor("#EE0F172A"));
        cardBg.setCornerRadius(28f);
        cardBg.setStroke(3, Color.parseColor("#38BDF8"));
        card.setBackground(cardBg);

        FrameLayout.LayoutParams cardParams = new FrameLayout.LayoutParams(panelWidth, panelHeight);
        cardParams.gravity = Gravity.CENTER;
        card.setLayoutParams(cardParams);

        LinearLayout header = new LinearLayout(activity);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(activity);
        title.setText("🛠️ MCPE Toolbox Overlay — Play Store Sync");
        title.setTextColor(Color.WHITE);
        title.setTextSize(15f);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        header.addView(title, titleLp);

        Button closeBtn = createStyledButton("✕ Tutup", "#EF4444");
        closeBtn.setOnClickListener(v -> toggleMainPanel());
        header.addView(closeBtn);
        card.addView(header);

        HorizontalScrollView tabScroll = new HorizontalScrollView(activity);
        LinearLayout tabRow = new LinearLayout(activity);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setPadding(0, 14, 0, 14);

        FrameLayout tabContentHolder = new FrameLayout(activity);
        LinearLayout.LayoutParams contentLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        );
        tabContentHolder.setLayoutParams(contentLp);

        final View tabGiveItem = buildGiveItemTab();
        final View tabPlayer = buildPlayerControlsTab();
        final View tabWorldBuilder = buildWorldAndBuilderTab();
        final View tabVisualHud = buildVisualHudTab();

        tabContentHolder.addView(tabGiveItem);
        tabContentHolder.addView(tabPlayer);
        tabContentHolder.addView(tabWorldBuilder);
        tabContentHolder.addView(tabVisualHud);

        Runnable hideAllTabs = () -> {
            tabGiveItem.setVisibility(View.GONE);
            tabPlayer.setVisibility(View.GONE);
            tabWorldBuilder.setVisibility(View.GONE);
            tabVisualHud.setVisibility(View.GONE);
        };

        Button btnTab1 = createStyledButton("🎒 Give Item & Enchant", "#0284C7");
        Button btnTab2 = createStyledButton("🏃 Player & Movement", "#334155");
        Button btnTab3 = createStyledButton("🏗️ World & Rapid Builder", "#334155");
        Button btnTab4 = createStyledButton("👁️ Visual & HUD", "#334155");

        btnTab1.setOnClickListener(v -> { hideAllTabs.run(); tabGiveItem.setVisibility(View.VISIBLE); });
        btnTab2.setOnClickListener(v -> { hideAllTabs.run(); tabPlayer.setVisibility(View.VISIBLE); });
        btnTab3.setOnClickListener(v -> { hideAllTabs.run(); tabWorldBuilder.setVisibility(View.VISIBLE); });
        btnTab4.setOnClickListener(v -> { hideAllTabs.run(); tabVisualHud.setVisibility(View.VISIBLE); });

        tabRow.addView(btnTab1);
        tabRow.addView(btnTab2);
        tabRow.addView(btnTab3);
        tabRow.addView(btnTab4);
        tabScroll.addView(tabRow);

        card.addView(tabScroll);

        hideAllTabs.run();
        tabGiveItem.setVisibility(View.VISIBLE);
        card.addView(tabContentHolder);

        return card;
    }

    private View buildGiveItemTab() {
        ScrollView scroll = new ScrollView(activity);
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(8, 8, 8, 8);

        layout.addView(createSectionHeader("Pilih Cepat Item Populer (1-Klik Masuk Inventory):"));

        String[][] quickItems = {
                {"⚔️ Netherite Sword", "minecraft:netherite_sword", "1"},
                {"⛏️ Netherite Pickaxe", "minecraft:netherite_pickaxe", "1"},
                {"🪽 Elytra", "minecraft:elytra", "1"},
                {"🎆 Firework Rocket x64", "minecraft:firework_rocket", "64"},
                {"🍎 Enchanted Golden Apple x64", "minecraft:enchanted_golden_apple", "64"},
                {"🗿 Totem of Undying", "minecraft:totem_of_undying", "1"},
                {"💎 Diamond x64", "minecraft:diamond", "64"},
                {"🧱 Netherite Ingot x64", "minecraft:netherite_ingot", "64"},
                {"🎛️ Command Block", "minecraft:command_block", "1"},
                {"🚧 Barrier Block x64", "minecraft:barrier", "64"},
                {"💡 Light Block x64", "minecraft:light_block", "64"},
                {"🔨 Mace (Senjata Baru)", "minecraft:mace", "1"}
        };

        LinearLayout currentRow = null;
        for (int i = 0; i < quickItems.length; i++) {
            if (i % 3 == 0) {
                currentRow = new LinearLayout(activity);
                currentRow.setOrientation(LinearLayout.HORIZONTAL);
                layout.addView(currentRow);
            }
            final String title = quickItems[i][0];
            final String itemId = quickItems[i][1];
            final int count = Integer.parseInt(quickItems[i][2]);

            Button itemBtn = createStyledButton(title, "#1E293B");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(6, 6, 6, 6);
            itemBtn.setLayoutParams(lp);
            itemBtn.setOnClickListener(v ->
                    ToolboxCommandDispatcher.giveItem(activity, itemId, count, 0)
            );
            currentRow.addView(itemBtn);
        }

        layout.addView(createSectionHeader("Kustom ID Item (Mendukung Semua Item Baru MCPE Play Store):"));
        LinearLayout customRow = new LinearLayout(activity);
        customRow.setOrientation(LinearLayout.HORIZONTAL);

        EditText inputItemId = new EditText(activity);
        inputItemId.setHint("Contoh: minecraft:wind_charge");
        inputItemId.setText("minecraft:wind_charge");
        inputItemId.setTextColor(Color.WHITE);
        inputItemId.setHintTextColor(Color.GRAY);
        LinearLayout.LayoutParams idLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f);
        customRow.addView(inputItemId, idLp);

        EditText inputCount = new EditText(activity);
        inputCount.setInputType(InputType.TYPE_CLASS_NUMBER);
        inputCount.setText("64");
        inputCount.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams countLp = new LinearLayout.LayoutParams(140, ViewGroup.LayoutParams.WRAP_CONTENT);
        customRow.addView(inputCount, countLp);

        Button btnGiveCustom = createStyledButton("➕ Berikan Item", "#10B981");
        btnGiveCustom.setOnClickListener(v -> {
            String id = inputItemId.getText().toString().trim();
            int cnt = 1;
            try { cnt = Integer.parseInt(inputCount.getText().toString().trim()); } catch (Exception ignored) {}
            ToolboxCommandDispatcher.giveItem(activity, id, cnt, 5);
        });
        customRow.addView(btnGiveCustom);

        layout.addView(customRow);
        scroll.addView(layout);
        return scroll;
    }

    private View buildPlayerControlsTab() {
        ScrollView scroll = new ScrollView(activity);
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(8, 8, 8, 8);

        layout.addView(createSectionHeader("Ubah Gamemode Cepat:"));
        LinearLayout gmRow = new LinearLayout(activity);
        gmRow.setOrientation(LinearLayout.HORIZONTAL);

        String[][] modes = {
                {"⚔️ Survival", "survival"},
                {"🎨 Creative", "creative"},
                {"👻 Spectator", "spectator"},
                {"🗺️ Adventure", "adventure"}
        };
        for (String[] m : modes) {
            Button b = createStyledButton(m[0], "#0369A1");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(6, 6, 6, 6);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> ToolboxCommandDispatcher.setGamemode(activity, m[1]));
            gmRow.addView(b);
        }
        layout.addView(gmRow);

        layout.addView(createSectionHeader("Kemampuan Karakter (Player Abilities):"));

        layout.addView(createToggleSwitch("☀️ Fullbright / Night Vision Tanpa Partikel", isFullbright, checked -> {
            isFullbright = checked;
            ToolboxCommandDispatcher.setPlayerAbility(activity, "fullbright", checked, 1);
            updateHudText();
        }));

        layout.addView(createToggleSwitch("🚀 Speed Boost & Auto-Step", isFlySpeedBoost, checked -> {
            isFlySpeedBoost = checked;
            ToolboxCommandDispatcher.setPlayerAbility(activity, "speed_boost", checked, currentSpeedAmplifier);
            updateHudText();
        }));

        layout.addView(createToggleSwitch("🛡️ God Mode (Kebal Damage + Fire Resistance + Saturation)", isGodMode, checked -> {
            isGodMode = checked;
            ToolboxCommandDispatcher.setPlayerAbility(activity, "god_mode", checked, 255);
            updateHudText();
        }));

        layout.addView(createToggleSwitch("⛏️ Fast Break / Haste Maksimal (Tambang Instan)", false, checked ->
                ToolboxCommandDispatcher.setPlayerAbility(activity, "instamine", checked, 10)
        ));

        scroll.addView(layout);
        return scroll;
    }

    private View buildWorldAndBuilderTab() {
        ScrollView scroll = new ScrollView(activity);
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(8, 8, 8, 8);

        layout.addView(createSectionHeader("Kontrol Waktu & Cuaca Dunia:"));
        LinearLayout timeRow = new LinearLayout(activity);
        timeRow.setOrientation(LinearLayout.HORIZONTAL);

        String[][] times = {{"🌅 Pagi", "sunrise"}, {"☀️ Siang", "noon"}, {"🌇 Sore", "sunset"}, {"🌙 Malam", "midnight"}};
        for (String[] t : times) {
            Button b = createStyledButton(t[0], "#1D4ED8");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(6, 6, 6, 6);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> ToolboxCommandDispatcher.setWorldEnvironment(activity, "time", t[1]));
            timeRow.addView(b);
        }
        layout.addView(timeRow);

        LinearLayout weatherRow = new LinearLayout(activity);
        weatherRow.setOrientation(LinearLayout.HORIZONTAL);
        String[][] weathers = {{"🌤️ Cerah", "clear"}, {"🌧️ Hujan", "rain"}, {"⛈️ Badai Petir", "thunder"}};
        for (String[] w : weathers) {
            Button b = createStyledButton(w[0], "#334155");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(6, 6, 6, 6);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> ToolboxCommandDispatcher.setWorldEnvironment(activity, "weather", w[1]));
            weatherRow.addView(b);
        }
        layout.addView(weatherRow);

        layout.addView(createSectionHeader("🏗️ Rapid Builder (Bangun Cepat di Sekitar Posisi Karakter):"));

        String[] buildBlocks = {
                "minecraft:stone_bricks",
                "minecraft:quartz_block",
                "minecraft:oak_planks",
                "minecraft:glass",
                "minecraft:obsidian",
                "minecraft:air"
        };
        Spinner blockSpinner = new Spinner(activity);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(activity, android.R.layout.simple_spinner_dropdown_item, buildBlocks);
        blockSpinner.setAdapter(adapter);
        layout.addView(blockSpinner);

        LinearLayout buildShapesRow = new LinearLayout(activity);
        buildShapesRow.setOrientation(LinearLayout.HORIZONTAL);

        String[][] shapes = {
                {"⬛ Platform Lantai (7x7)", "platform"},
                {"🏰 Dinding Pelindung", "walls"},
                {"🌐 Kubah Bola (Sphere)", "sphere"},
                {"🧹 Bersihkan Area (Air)", "clear_area"}
        };
        for (String[] s : shapes) {
            Button b = createStyledButton(s[0], "#0D9488");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(6, 6, 6, 6);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                selectedBuildBlock = blockSpinner.getSelectedItem().toString();
                ToolboxCommandDispatcher.executeRapidBuild(activity, s[1], selectedBuildBlock, buildRadius);
            });
            buildShapesRow.addView(b);
        }
        layout.addView(buildShapesRow);

        scroll.addView(layout);
        return scroll;
    }

    private View buildVisualHudTab() {
        ScrollView scroll = new ScrollView(activity);
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(8, 8, 8, 8);

        layout.addView(createSectionHeader("Pengaturan HUD & Kamera:"));

        layout.addView(createToggleSwitch("📊 Tampilkan Indikator HUD (FPS & Status Aktif)", true, checked ->
                hudTextView.setVisibility(checked ? View.VISIBLE : View.GONE)
        ));

        layout.addView(createSectionHeader("Tingkat Perbesaran Kamera (Zoom Slider: 1.0x - 8.0x):"));

        SeekBar zoomSeek = new SeekBar(activity);
        zoomSeek.setMax(70);
        zoomSeek.setProgress(0);
        zoomSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                float factor = 1.0f + (progress / 10.0f);
                ToolboxCommandDispatcher.safeSetZoomFactor(factor);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        layout.addView(zoomSeek);

        scroll.addView(layout);
        return scroll;
    }

    private TextView createSectionHeader(String text) {
        TextView tv = new TextView(activity);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#93C5FD"));
        tv.setTextSize(13f);
        tv.setPadding(4, 16, 4, 8);
        return tv;
    }

    private Button createStyledButton(String text, String hexColor) {
        Button btn = new Button(activity);
        btn.setText(text);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(12f);
        btn.setAllCaps(false);
        btn.setPadding(20, 12, 20, 12);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(hexColor));
        bg.setCornerRadius(14f);
        btn.setBackground(bg);
        return btn;
    }

    public interface OnToggleListener {
        void onChanged(boolean isChecked);
    }

    private Switch createToggleSwitch(String label, boolean initialValue, OnToggleListener listener) {
        Switch sw = new Switch(activity);
        sw.setText(label);
        sw.setTextColor(Color.WHITE);
        sw.setTextSize(13f);
        sw.setChecked(initialValue);
        sw.setPadding(12, 14, 12, 14);
        sw.setOnCheckedChangeListener((buttonView, isChecked) -> listener.onChanged(isChecked));
        return sw;
    }

    private void startFpsCounter() {
        Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() {
            @Override
            public void doFrame(long frameTimeNanos) {
                if (lastFrameTimeNanos == 0) {
                    lastFrameTimeNanos = frameTimeNanos;
                }
                frameCount++;
                long elapsedNanos = frameTimeNanos - lastFrameTimeNanos;
                if (elapsedNanos >= 1_000_000_000L) {
                    currentFps = frameCount;
                    frameCount = 0;
                    lastFrameTimeNanos = frameTimeNanos;
                    updateHudText();
                }
                Choreographer.getInstance().postFrameCallback(this);
            }
        });
    }
}
