package com.toolbox.mcpelauncher.overlay;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import com.toolbox.mcpelauncher.bridge.ToolboxCommandDispatcher;

public class ToolboxOverlayManager {

    private final Context context;
    private final WindowManager windowManager;
    private final Runnable onExitCallback;

    private TextView hudWindowView;
    private TextView crosshairView;
    private View floatingButtonView;
    private View mainPanelView;
    private TextView lastCmdBanner;

    private boolean isRunning = false;
    private boolean isMenuOpen = false;
    private boolean isFullbright = false;
    private boolean isSpeedBoost = false;
    private boolean isGodMode = false;
    private boolean isCrosshairActive = false;
    private String selectedBuildBlock = "stone_bricks";
    private int buildRadius = 4;

    private long lastFrameTimeNanos = 0;
    private int frameCount = 0;
    private int currentFps = 60;

    public ToolboxOverlayManager(Context context, Runnable onExitCallback) {
        this.context = context;
        this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        this.onExitCallback = onExitCallback;
    }

    private int getOverlayType() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
        return WindowManager.LayoutParams.TYPE_PHONE;
    }

    public void showOverlayWindows() {
        if (isRunning) return;
        isRunning = true;

        // 1. Jendela HUD Indikator FPS (Tidak memblokir sentuhan game sama sekali!)
        hudWindowView = createHudView();
        WindowManager.LayoutParams hudParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                getOverlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        hudParams.gravity = Gravity.TOP | Gravity.START;
        hudParams.x = 24;
        hudParams.y = 18;
        windowManager.addView(hudWindowView, hudParams);

        // 2. Crosshair Pembidik Tengah Layar (Opsional, tidak memblokir sentuhan)
        crosshairView = createCrosshairView();
        crosshairView.setVisibility(View.GONE);
        WindowManager.LayoutParams crossParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                getOverlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        crossParams.gravity = Gravity.CENTER;
        windowManager.addView(crosshairView, crossParams);

        // 3. Jendela Panel Utama Toolbox (Hanya muncul saat tombol 🛠️ TB ditekan)
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        int panelW = (int) (Math.max(dm.widthPixels, dm.heightPixels) * 0.78f);
        int panelH = (int) (Math.min(dm.widthPixels, dm.heightPixels) * 0.84f);

        mainPanelView = createMainToolboxPanel();
        mainPanelView.setVisibility(View.GONE);
        WindowManager.LayoutParams panelParams = new WindowManager.LayoutParams(
                panelW,
                panelH,
                getOverlayType(),
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        panelParams.gravity = Gravity.CENTER;
        windowManager.addView(mainPanelView, panelParams);

        // 4. Tombol Mengambang Utama [🛠️ TB] (Bisa digeser bebas ke seluruh layar)
        WindowManager.LayoutParams btnParams = new WindowManager.LayoutParams(
                138,
                138,
                getOverlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        btnParams.gravity = Gravity.TOP | Gravity.START;
        btnParams.x = 28;
        btnParams.y = 120;
        floatingButtonView = createDraggableFloatingButton(btnParams);
        windowManager.addView(floatingButtonView, btnParams);

        startFpsCounter();
    }

    public void removeAllOverlayWindows() {
        isRunning = false;
        safeRemoveView(hudWindowView);
        safeRemoveView(crosshairView);
        safeRemoveView(mainPanelView);
        safeRemoveView(floatingButtonView);
    }

    private void safeRemoveView(View v) {
        if (v != null && windowManager != null) {
            try {
                windowManager.removeView(v);
            } catch (Exception ignored) {
            }
        }
    }

    private TextView createHudView() {
        TextView tv = new TextView(context);
        tv.setTextColor(Color.parseColor("#E0F2FE"));
        tv.setTextSize(11.5f);
        tv.setPadding(20, 10, 20, 10);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#AA0F172A"));
        bg.setCornerRadius(14f);
        bg.setStroke(2, Color.parseColor("#38BDF8"));
        tv.setBackground(bg);

        updateHudText(tv);
        return tv;
    }

    private TextView createCrosshairView() {
        TextView tv = new TextView(context);
        tv.setText("➕");
        tv.setTextColor(Color.parseColor("#22D3EE"));
        tv.setTextSize(18f);
        return tv;
    }

    private void updateHudText(TextView tv) {
        if (tv == null) return;
        StringBuilder sb = new StringBuilder();
        sb.append("⚡ FPS: ").append(currentFps);
        if (isFullbright) sb.append(" | ☀️ Fullbright");
        if (isSpeedBoost) sb.append(" | 🚀 Speed+");
        if (isGodMode) sb.append(" | 🛡️ GodMode");
        tv.setText(sb.toString());
    }

    private View createDraggableFloatingButton(final WindowManager.LayoutParams btnParams) {
        Button btn = new Button(context);
        btn.setText("🛠️ TB");
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(12.5f);
        btn.setAllCaps(false);
        btn.setPadding(8, 8, 8, 8);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#E60284C7"));
        bg.setCornerRadius(100f);
        bg.setStroke(3, Color.parseColor("#7DD3FC"));
        btn.setBackground(bg);

        btn.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            private boolean isDragged = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = btnParams.x;
                        initialY = btnParams.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        isDragged = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - initialTouchX);
                        int dy = (int) (event.getRawY() - initialTouchY);
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            isDragged = true;
                            btnParams.x = Math.max(0, initialX + dx);
                            btnParams.y = Math.max(0, initialY + dy);
                            try {
                                windowManager.updateViewLayout(v, btnParams);
                            } catch (Exception ignored) {
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!isDragged) {
                            toggleMainPanel();
                        }
                        return true;
                }
                return false;
            }
        });

        return btn;
    }

    private void toggleMainPanel() {
        isMenuOpen = !isMenuOpen;
        if (mainPanelView != null) {
            mainPanelView.setVisibility(isMenuOpen ? View.VISIBLE : View.GONE);
            if (lastCmdBanner != null) {
                lastCmdBanner.setText("📋 Perintah Terakhir di Clipboard: " + ToolboxCommandDispatcher.getLastCommand());
            }
        }
    }

    private View createMainToolboxPanel() {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(28, 22, 28, 22);

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.parseColor("#F20F172A"));
        cardBg.setCornerRadius(24f);
        cardBg.setStroke(3, Color.parseColor("#38BDF8"));
        card.setBackground(cardBg);

        // Baris Header
        LinearLayout header = new LinearLayout(context);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(context);
        title.setText("🛠️ MCPE Toolbox Overlay v2.0 (Anti-Force Close)");
        title.setTextColor(Color.WHITE);
        title.setTextSize(14.5f);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        header.addView(title, titleLp);

        Button exitOverlayBtn = createStyledButton("🚪 Matikan TB", "#64748B");
        LinearLayout.LayoutParams exitLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        exitLp.rightMargin = 12;
        exitOverlayBtn.setLayoutParams(exitLp);
        exitOverlayBtn.setOnClickListener(v -> {
            if (onExitCallback != null) onExitCallback.run();
        });
        header.addView(exitOverlayBtn);

        Button closeBtn = createStyledButton("✕ Sembunyikan", "#EF4444");
        closeBtn.setOnClickListener(v -> toggleMainPanel());
        header.addView(closeBtn);
        card.addView(header);

        // Banner Status Clipboard Otomatis
        lastCmdBanner = new TextView(context);
        lastCmdBanner.setText("💡 Klik tombol apa saja -> Otomatis tersalin & siap Paste di Chat MCPE!");
        lastCmdBanner.setTextColor(Color.parseColor("#FDE047"));
        lastCmdBanner.setTextSize(11.5f);
        lastCmdBanner.setPadding(8, 10, 8, 6);
        card.addView(lastCmdBanner);

        // Baris Navigasi Tab
        HorizontalScrollView tabScroll = new HorizontalScrollView(context);
        LinearLayout tabRow = new LinearLayout(context);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setPadding(0, 8, 0, 10);

        FrameLayout tabContentHolder = new FrameLayout(context);
        LinearLayout.LayoutParams contentLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        );
        tabContentHolder.setLayoutParams(contentLp);

        final View tabGiveItem = buildGiveItemTab();
        final View tabPlayer = buildPlayerControlsTab();
        final View tabWorldBuilder = buildWorldAndBuilderTab();
        final View tabVisualHud = buildVisualHudTab();

        tabContentHolder.addView(tabGiveItem);
        tabContentHolder.addView(tabPlayer);
        tabContentHolder.addView(tabWorldBuilder);
        tabContentHolder.addView(tabVisualHud);

        Runnable hideAllTabs = () -> {
            tabGiveItem.setVisibility(View.GONE);
            tabPlayer.setVisibility(View.GONE);
            tabWorldBuilder.setVisibility(View.GONE);
            tabVisualHud.setVisibility(View.GONE);
        };

        Button btnTab1 = createStyledButton("🎒 Give Item & Kit", "#0284C7");
        Button btnTab2 = createStyledButton("🏃 Player & Efek", "#334155");
        Button btnTab3 = createStyledButton("🏗️ World & Rapid Builder", "#334155");
        Button btnTab4 = createStyledButton("👁️ HUD & Crosshair", "#334155");

        btnTab1.setOnClickListener(v -> { hideAllTabs.run(); tabGiveItem.setVisibility(View.VISIBLE); });
        btnTab2.setOnClickListener(v -> { hideAllTabs.run(); tabPlayer.setVisibility(View.VISIBLE); });
        btnTab3.setOnClickListener(v -> { hideAllTabs.run(); tabWorldBuilder.setVisibility(View.VISIBLE); });
        btnTab4.setOnClickListener(v -> { hideAllTabs.run(); tabVisualHud.setVisibility(View.VISIBLE); });

        tabRow.addView(btnTab1);
        tabRow.addView(btnTab2);
        tabRow.addView(btnTab3);
        tabRow.addView(btnTab4);
        tabScroll.addView(tabRow);
        card.addView(tabScroll);

        hideAllTabs.run();
        tabGiveItem.setVisibility(View.VISIBLE);
        card.addView(tabContentHolder);

        return card;
    }

    private View buildGiveItemTab() {
        ScrollView scroll = new ScrollView(context);
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(6, 6, 6, 6);

        layout.addView(createSectionHeader("Pilih Cepat Item (Klik -> Otomatis Salin & Tutup Panel):"));

        String[][] quickItems = {
                {"⚔️ Netherite Sword", "netherite_sword", "1"},
                {"⛏️ Netherite Pickaxe", "netherite_pickaxe", "1"},
                {"🪽 Elytra", "elytra", "1"},
                {"🎆 Firework x64", "firework_rocket", "64"},
                {"🍎 God Apple x64", "enchanted_golden_apple", "64"},
                {"🗿 Totem Undying", "totem_of_undying", "1"},
                {"💎 Diamond Block x64", "diamond_block", "64"},
                {"🧱 Netherite Block x64", "netherite_block", "64"},
                {"🎛️ Command Block", "command_block", "1"},
                {"🚧 Barrier x64", "barrier", "64"},
                {"🔨 Mace (Senjata Baru)", "mace", "1"},
                {"💨 Wind Charge x64", "wind_charge", "64"}
        };

        LinearLayout currentRow = null;
        for (int i = 0; i < quickItems.length; i++) {
            if (i % 3 == 0) {
                currentRow = new LinearLayout(context);
                currentRow.setOrientation(LinearLayout.HORIZONTAL);
                layout.addView(currentRow);
            }
            final String title = quickItems[i][0];
            final String itemId = quickItems[i][1];
            final int count = Integer.parseInt(quickItems[i][2]);

            Button itemBtn = createStyledButton(title, "#1E293B");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(5, 5, 5, 5);
            itemBtn.setLayoutParams(lp);
            itemBtn.setOnClickListener(v -> {
                ToolboxCommandDispatcher.giveItem(context, itemId, count, false);
                toggleMainPanel();
            });
            currentRow.addView(itemBtn);
        }

        layout.addView(createSectionHeader("Ketik Nama Item Kustom & Jumlah:"));
        LinearLayout customRow = new LinearLayout(context);
        customRow.setOrientation(LinearLayout.HORIZONTAL);

        EditText inputItemId = new EditText(context);
        inputItemId.setHint("Contoh: trident ataulectern");
        inputItemId.setText("trident");
        inputItemId.setTextColor(Color.WHITE);
        inputItemId.setHintTextColor(Color.GRAY);
        LinearLayout.LayoutParams idLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f);
        customRow.addView(inputItemId, idLp);

        EditText inputCount = new EditText(context);
        inputCount.setInputType(InputType.TYPE_CLASS_NUMBER);
        inputCount.setText("1");
        inputCount.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams countLp = new LinearLayout.LayoutParams(120, ViewGroup.LayoutParams.WRAP_CONTENT);
        customRow.addView(inputCount, countLp);

        Button btnGiveCustom = createStyledButton("➕ Salin Perintah Give", "#10B981");
        btnGiveCustom.setOnClickListener(v -> {
            String id = inputItemId.getText().toString().trim();
            int cnt = 1;
            try { cnt = Integer.parseInt(inputCount.getText().toString().trim()); } catch (Exception ignored) {}
            ToolboxCommandDispatcher.giveItem(context, id, cnt, true);
            toggleMainPanel();
        });
        customRow.addView(btnGiveCustom);

        layout.addView(customRow);
        scroll.addView(layout);
        return scroll;
    }

    private View buildPlayerControlsTab() {
        ScrollView scroll = new ScrollView(context);
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(6, 6, 6, 6);

        layout.addView(createSectionHeader("Ubah Gamemode Instan:"));
        LinearLayout gmRow = new LinearLayout(context);
        gmRow.setOrientation(LinearLayout.HORIZONTAL);

        String[][] modes = {
                {"⚔️ Survival", "s"},
                {"🎨 Creative", "c"},
                {"👻 Spectator", "spectator"},
                {"🗺️ Adventure", "a"}
        };
        for (String[] m : modes) {
            Button b = createStyledButton(m[0], "#0369A1");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(5, 5, 5, 5);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                ToolboxCommandDispatcher.setGamemode(context, m[1]);
                toggleMainPanel();
            });
            gmRow.addView(b);
        }
        layout.addView(gmRow);

        layout.addView(createSectionHeader("Kemampuan Karakter (Abilities & Efek Tanpa Partikel):"));

        layout.addView(createToggleSwitch("☀️ Fullbright (Night Vision Terang Maksimal)", isFullbright, checked -> {
            isFullbright = checked;
            ToolboxCommandDispatcher.setPlayerAbility(context, "fullbright", checked, 1);
            updateHudText(hudWindowView);
        }));

        layout.addView(createToggleSwitch("🚀 Speed Boost Lari Cepat (Speed IV)", isSpeedBoost, checked -> {
            isSpeedBoost = checked;
            ToolboxCommandDispatcher.setPlayerAbility(context, "speed_boost", checked, 4);
            updateHudText(hudWindowView);
        }));

        layout.addView(createToggleSwitch("🛡️ God Mode (Kebal Semua Serangan / Resistance 255)", isGodMode, checked -> {
            isGodMode = checked;
            ToolboxCommandDispatcher.setPlayerAbility(context, "god_mode", checked, 255);
            updateHudText(hudWindowView);
        }));

        layout.addView(createToggleSwitch("⛏️ Insta-Mine / Fast Break (Haste X)", false, checked ->
                ToolboxCommandDispatcher.setPlayerAbility(context, "instamine", checked, 10)
        ));

        layout.addView(createToggleSwitch("🪽 Aktifkan Terbang di Survival (/ability mayfly)", false, checked ->
                ToolboxCommandDispatcher.setPlayerAbility(context, "fly_levitation", checked, 1)
        ));

        scroll.addView(layout);
        return scroll;
    }

    private View buildWorldAndBuilderTab() {
        ScrollView scroll = new ScrollView(context);
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(6, 6, 6, 6);

        layout.addView(createSectionHeader("Kontrol Waktu & Cuaca Dunia:"));
        LinearLayout timeRow = new LinearLayout(context);
        timeRow.setOrientation(LinearLayout.HORIZONTAL);

        String[][] times = {{"🌅 Pagi", "sunrise"}, {"☀️ Siang", "noon"}, {"🌇 Sore", "sunset"}, {"🌙 Malam", "midnight"}};
        for (String[] t : times) {
            Button b = createStyledButton(t[0], "#1D4ED8");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(5, 5, 5, 5);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                ToolboxCommandDispatcher.setWorldEnvironment(context, "time", t[1]);
                toggleMainPanel();
            });
            timeRow.addView(b);
        }
        layout.addView(timeRow);

        LinearLayout weatherRow = new LinearLayout(context);
        weatherRow.setOrientation(LinearLayout.HORIZONTAL);
        String[][] weathers = {{"🌤️ Cerah", "clear"}, {"🌧️ Hujan", "rain"}, {"⛈️ Badai", "thunder"}, {"🧹 Hapus Item Lag", "clear_lag"}};
        for (String[] w : weathers) {
            Button b = createStyledButton(w[0], "#334155");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(5, 5, 5, 5);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                ToolboxCommandDispatcher.setWorldEnvironment(context, "clear_lag".equals(w[1]) ? "lag" : "weather", w[1]);
                toggleMainPanel();
            });
            weatherRow.addView(b);
        }
        layout.addView(weatherRow);

        // Gunakan tombol pilihan blok (Bukan Spinner) agar 100% bebas BadTokenException di Overlay Service!
        final TextView selectedBlockLabel = createSectionHeader("🧱 Material Rapid Builder Saat Ini: " + selectedBuildBlock);
        layout.addView(selectedBlockLabel);

        HorizontalScrollView blockScroll = new HorizontalScrollView(context);
        LinearLayout blockRow = new LinearLayout(context);
        blockRow.setOrientation(LinearLayout.HORIZONTAL);
        String[][] blockChoices = {
                {"🧱 Stone Bricks", "stone_bricks"},
                {"🏛️ Quartz", "quartz_block"},
                {"🪵 Oak Planks", "oak_planks"},
                {"🪟 Glass", "glass"},
                {"🟣 Obsidian", "obsidian"},
                {"💎 Diamond Block", "diamond_block"}
        };
        for (String[] bc : blockChoices) {
            Button b = createStyledButton(bc[0], "#475569");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            lp.setMargins(5, 5, 5, 5);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                selectedBuildBlock = bc[1];
                selectedBlockLabel.setText("🧱 Material Rapid Builder Saat Ini: " + selectedBuildBlock);
            });
            blockRow.addView(b);
        }
        blockScroll.addView(blockRow);
        layout.addView(blockScroll);

        layout.addView(createSectionHeader("🏗️ Bangun Otomatis di Sekitar Posisi Karaktermu:"));
        LinearLayout buildShapesRow = new LinearLayout(context);
        buildShapesRow.setOrientation(LinearLayout.HORIZONTAL);

        String[][] shapes = {
                {"⬛ Lantai 9x9", "platform"},
                {"🏰 Benteng Dinding", "walls"},
                {"🏠 Ruangan Hollow", "hollow_box"},
                {"🧹 Ratakan Area (Air)", "clear_area"}
        };
        for (String[] s : shapes) {
            Button b = createStyledButton(s[0], "#0D9488");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(5, 5, 5, 5);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                ToolboxCommandDispatcher.executeRapidBuild(context, s[1], selectedBuildBlock, buildRadius);
                toggleMainPanel();
            });
            buildShapesRow.addView(b);
        }
        layout.addView(buildShapesRow);

        scroll.addView(layout);
        return scroll;
    }

    private View buildVisualHudTab() {
        ScrollView scroll = new ScrollView(context);
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(6, 6, 6, 6);

        layout.addView(createSectionHeader("Pengaturan Visual & HUD Overlay:"));

        layout.addView(createToggleSwitch("📊 Tampilkan HUD Indikator FPS di Pojok Kiri Atas", true, checked -> {
            if (hudWindowView != null) {
                hudWindowView.setVisibility(checked ? View.VISIBLE : View.GONE);
            }
        }));

        layout.addView(createToggleSwitch("➕ Tampilkan Crosshair Pembidik Tengah Layar", isCrosshairActive, checked -> {
            isCrosshairActive = checked;
            if (crosshairView != null) {
                crosshairView.setVisibility(checked ? View.VISIBLE : View.GONE);
            }
        }));

        scroll.addView(layout);
        return scroll;
    }

    private TextView createSectionHeader(String text) {
        TextView tv = new TextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#93C5FD"));
        tv.setTextSize(12.5f);
        tv.setPadding(4, 14, 4, 6);
        return tv;
    }

    private Button createStyledButton(String text, String hexColor) {
        Button btn = new Button(context);
        btn.setText(text);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(11.5f);
        btn.setAllCaps(false);
        btn.setPadding(18, 12, 18, 12);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(hexColor));
        bg.setCornerRadius(14f);
        btn.setBackground(bg);
        return btn;
    }

    public interface OnToggleListener {
        void onChanged(boolean isChecked);
    }

    private Switch createToggleSwitch(String label, boolean initialValue, OnToggleListener listener) {
        Switch sw = new Switch(context);
        sw.setText(label);
        sw.setTextColor(Color.WHITE);
        sw.setTextSize(12.5f);
        sw.setChecked(initialValue);
        sw.setPadding(10, 12, 10, 12);
        sw.setOnCheckedChangeListener((buttonView, isChecked) -> listener.onChanged(isChecked));
        return sw;
    }

    private void startFpsCounter() {
        Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() {
            @Override
            public void doFrame(long frameTimeNanos) {
                if (!isRunning) return;
                if (lastFrameTimeNanos == 0) {
                    lastFrameTimeNanos = frameTimeNanos;
                }
                frameCount++;
                long elapsedNanos = frameTimeNanos - lastFrameTimeNanos;
                if (elapsedNanos >= 1_000_000_000L) {
                    currentFps = frameCount;
                    frameCount = 0;
                    lastFrameTimeNanos = frameTimeNanos;
                    updateHudText(hudWindowView);
                }
                Choreographer.getInstance().postFrameCallback(this);
            }
        });
    }
}
