package com.toolbox.mcpelauncher.overlay;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.provider.Settings;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.toolbox.mcpelauncher.automation.ToolboxAutoService;
import com.toolbox.mcpelauncher.bridge.LevelDatPatcher;
import com.toolbox.mcpelauncher.bridge.ToolboxCommandDispatcher;
import com.toolbox.mcpelauncher.bridge.ToolboxWebSocketServer;
import com.toolbox.mcpelauncher.core.TrueFpsAndLanScanner;

import java.util.Locale;

public class ToolboxOverlayManager {

    private final Context context;
    private final WindowManager windowManager;
    private final Runnable onExitCallback;

    private TextView hudWindowView;
    private TextView crosshairView;
    private View floatingButtonView;
    private Button quickAuraButtonView;
    private View mainPanelView;
    private TextView engineStatusBanner;
    private TextView lanStatusTextView;

    private TrueFpsAndLanScanner telemetryScanner;

    private boolean isRunning = false;
    private boolean isMenuOpen = false;
    private boolean isFullbright = false;
    private boolean isSpeedBoost = false;
    private boolean isGodMode = false;
    private boolean isCrosshairActive = false;
    private String selectedBuildBlock = "stone_bricks";
    private int buildRadius = 4;

    private int currentRealFps = 60;
    private float currentFrameMs = 16.6f;
    private int currentOnePercentLow = 55;
    private String currentLanText = "📡 Wi-Fi/Hotspot: Siap memindai...";

    public ToolboxOverlayManager(Context context, Runnable onExitCallback) {
        this.context = context;
        this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        this.onExitCallback = onExitCallback;
    }

    private int getOverlayType() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        }
        return WindowManager.LayoutParams.TYPE_PHONE;
    }

    public void showOverlayWindows() {
        if (isRunning) return;
        isRunning = true;

        // 1. Jendela HUD True FPS & Frame-Time ms + Status Engine
        hudWindowView = createHudView();
        WindowManager.LayoutParams hudParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                getOverlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        hudParams.gravity = Gravity.TOP | Gravity.START;
        hudParams.x = 24;
        hudParams.y = 16;
        windowManager.addView(hudWindowView, hudParams);

        // 2. Crosshair Pembidik Tengah Layar (Bantu bidik Kill Aura di Wi-Fi/Hotspot)
        crosshairView = createCrosshairView();
        crosshairView.setVisibility(View.GONE);
        WindowManager.LayoutParams crossParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                getOverlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        crossParams.gravity = Gravity.CENTER;
        windowManager.addView(crosshairView, crossParams);

        // 3. Panel Menu Utama Toolbox (5 Tab)
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        int panelW = (int) (Math.max(dm.widthPixels, dm.heightPixels) * 0.80f);
        int panelH = (int) (Math.min(dm.widthPixels, dm.heightPixels) * 0.85f);

        mainPanelView = createMainToolboxPanel();
        mainPanelView.setVisibility(View.GONE);
        WindowManager.LayoutParams panelParams = new WindowManager.LayoutParams(
                panelW,
                panelH,
                getOverlayType(),
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        panelParams.gravity = Gravity.CENTER;
        windowManager.addView(mainPanelView, panelParams);

        // 4. Tombol Mengambang Utama [🛠️ TB]
        WindowManager.LayoutParams btnParams = new WindowManager.LayoutParams(
                136,
                136,
                getOverlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        btnParams.gravity = Gravity.TOP | Gravity.START;
        btnParams.x = 26;
        btnParams.y = 110;
        floatingButtonView = createDraggableFloatingButton(btnParams);
        windowManager.addView(floatingButtonView, btnParams);

        // 5. Tombol Cepat [⚔️ Aura] di Sisi Kanan Layar (Untuk PvP/PvE di World Teman Wi-Fi/Hotspot!)
        WindowManager.LayoutParams auraParams = new WindowManager.LayoutParams(
                136,
                136,
                getOverlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        auraParams.gravity = Gravity.CENTER_VERTICAL | Gravity.END;
        auraParams.x = 26;
        auraParams.y = 0;
        quickAuraButtonView = createQuickKillAuraButton(auraParams);
        windowManager.addView(quickAuraButtonView, auraParams);

        // Mulai True FPS & LAN RakNet Scanner
        telemetryScanner = new TrueFpsAndLanScanner((realFps, avgFrameMs, onePercentLow, lanText) -> {
            currentRealFps = realFps;
            currentFrameMs = avgFrameMs;
            currentOnePercentLow = onePercentLow;
            currentLanText = lanText;
            updateHudText();
            if (lanStatusTextView != null) {
                lanStatusTextView.setText(lanText);
            }
        });
        telemetryScanner.start();
    }

    public void removeAllOverlayWindows() {
        isRunning = false;
        if (telemetryScanner != null) {
            telemetryScanner.stop();
        }
        ToolboxAutoService autoSvc = ToolboxAutoService.getInstance();
        if (autoSvc != null) {
            autoSvc.setKillAuraEnabled(false);
        }
        safeRemoveView(hudWindowView);
        safeRemoveView(crosshairView);
        safeRemoveView(mainPanelView);
        safeRemoveView(floatingButtonView);
        safeRemoveView(quickAuraButtonView);
    }

    private void safeRemoveView(View v) {
        if (v != null && windowManager != null) {
            try {
                windowManager.removeView(v);
            } catch (Exception ignored) {
            }
        }
    }

    private TextView createHudView() {
        TextView tv = new TextView(context);
        tv.setTextColor(Color.parseColor("#E0F2FE"));
        tv.setTextSize(11f);
        tv.setPadding(18, 8, 18, 8);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#B30F172A"));
        bg.setCornerRadius(14f);
        bg.setStroke(2, Color.parseColor("#38BDF8"));
        tv.setBackground(bg);

        return tv;
    }

    private TextView createCrosshairView() {
        TextView tv = new TextView(context);
        tv.setText("🎯");
        tv.setTextColor(Color.parseColor("#F43F5E"));
        tv.setTextSize(18f);
        return tv;
    }

    private void updateHudText() {
        if (hudWindowView == null) return;
        boolean wsConnected = ToolboxWebSocketServer.getInstance().hasConnectedGameEngine();
        boolean auraOn = ToolboxAutoService.getInstance() != null && ToolboxAutoService.getInstance().isKillAuraEnabled();

        StringBuilder sb = new StringBuilder();
        sb.append(String.format(Locale.US, "⚡ %d FPS (%.1f ms | 1%%Low: %d)", currentRealFps, currentFrameMs, currentOnePercentLow));
        sb.append(wsConnected ? " | 🟢 Engine: Direct" : " | 🟡 Engine: Standby");
        if (auraOn) sb.append(" | ⚔️ KillAura ON");
        if (isFullbright) sb.append(" | ☀️ Fullbright");
        if (isGodMode) sb.append(" | 🛡️ GodMode");
        hudWindowView.setText(sb.toString());
    }

    private View createDraggableFloatingButton(final WindowManager.LayoutParams btnParams) {
        Button btn = new Button(context);
        btn.setText("🛠️ TB");
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(12f);
        btn.setAllCaps(false);
        btn.setPadding(6, 6, 6, 6);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#E60284C7"));
        bg.setCornerRadius(100f);
        bg.setStroke(3, Color.parseColor("#7DD3FC"));
        btn.setBackground(bg);

        btn.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            private boolean isDragged = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = btnParams.x;
                        initialY = btnParams.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        isDragged = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - initialTouchX);
                        int dy = (int) (event.getRawY() - initialTouchY);
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            isDragged = true;
                            btnParams.x = Math.max(0, initialX + dx);
                            btnParams.y = Math.max(0, initialY + dy);
                            try {
                                windowManager.updateViewLayout(v, btnParams);
                            } catch (Exception ignored) {
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!isDragged) {
                            toggleMainPanel();
                        }
                        return true;
                }
                return false;
            }
        });

        return btn;
    }

    private Button createQuickKillAuraButton(final WindowManager.LayoutParams auraParams) {
        Button btn = new Button(context);
        btn.setText("⚔️\nOFF");
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(10.5f);
        btn.setAllCaps(false);
        btn.setPadding(6, 6, 6, 6);

        final GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#CC1E293B"));
        bg.setCornerRadius(100f);
        bg.setStroke(3, Color.parseColor("#F43F5E"));
        btn.setBackground(bg);

        btn.setOnClickListener(v -> {
            ToolboxAutoService autoSvc = ToolboxAutoService.getInstance();
            if (autoSvc == null) {
                Toast.makeText(context, "Aktifkan dulu layanan 'MCPE Toolbox Combat & Direct Engine' di Pengaturan Aksesibilitas HP!", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return;
            }
            boolean nextState = !autoSvc.isKillAuraEnabled();
            autoSvc.setKillAuraEnabled(nextState);
            btn.setText(nextState ? "⚔️\nON" : "⚔️\nOFF");
            bg.setColor(Color.parseColor(nextState ? "#EEBE123C" : "#CC1E293B"));
            updateHudText();
        });

        return btn;
    }

    private void toggleMainPanel() {
        isMenuOpen = !isMenuOpen;
        if (mainPanelView != null) {
            mainPanelView.setVisibility(isMenuOpen ? View.VISIBLE : View.GONE);
            refreshEngineBanner();
        }
    }

    private void refreshEngineBanner() {
        if (engineStatusBanner == null) return;
        boolean wsOk = ToolboxWebSocketServer.getInstance().hasConnectedGameEngine();
        boolean accOk = ToolboxAutoService.isServiceConnected();
        if (wsOk) {
            engineStatusBanner.setText("🟢 DIRECT ENGINE AKTIF: Semua item & fitur langsung mengubah dunia secara instan tanpa buka chat!");
            engineStatusBanner.setTextColor(Color.parseColor("#4ADE80"));
        } else if (accOk) {
            engineStatusBanner.setText("🟢 AUTO-ENGINE & KILL AURA SIAP: Klik '⚡ Hubungkan Direct Engine' sekali agar item masuk instan tanpa chat!");
            engineStatusBanner.setTextColor(Color.parseColor("#38BDF8"));
        } else {
            engineStatusBanner.setText("🟡 Tekan '⚡ Hubungkan Direct Engine' atau '🤖 Aktifkan Aksesibilitas' agar item & Kill Aura berjalan otomatis!");
            engineStatusBanner.setTextColor(Color.parseColor("#FDE047"));
        }
    }

    private View createMainToolboxPanel() {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(24, 18, 24, 18);

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.parseColor("#F40F172A"));
        cardBg.setCornerRadius(24f);
        cardBg.setStroke(3, Color.parseColor("#38BDF8"));
        card.setBackground(cardBg);

        // Baris Header
        LinearLayout header = new LinearLayout(context);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(context);
        title.setText("🛠️ MCPE Toolbox Pro v3.0 — Direct Engine + Wi-Fi/Hotspot Combat");
        title.setTextColor(Color.WHITE);
        title.setTextSize(13.5f);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        header.addView(title, titleLp);

        Button connectWsBtn = createStyledButton("⚡ Hubungkan Direct Engine", "#10B981");
        LinearLayout.LayoutParams wsLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        wsLp.rightMargin = 10;
        connectWsBtn.setLayoutParams(wsLp);
        connectWsBtn.setOnClickListener(v -> {
            ToolboxCommandDispatcher.connectDirectEngineSocket(context);
            toggleMainPanel();
        });
        header.addView(connectWsBtn);

        Button exitOverlayBtn = createStyledButton("🚪 Matikan TB", "#64748B");
        LinearLayout.LayoutParams exitLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        exitLp.rightMargin = 10;
        exitOverlayBtn.setLayoutParams(exitLp);
        exitOverlayBtn.setOnClickListener(v -> {
            if (onExitCallback != null) onExitCallback.run();
        });
        header.addView(exitOverlayBtn);

        Button closeBtn = createStyledButton("✕ Tutup", "#EF4444");
        closeBtn.setOnClickListener(v -> toggleMainPanel());
        header.addView(closeBtn);
        card.addView(header);

        engineStatusBanner = new TextView(context);
        engineStatusBanner.setTextSize(11f);
        engineStatusBanner.setPadding(6, 8, 6, 4);
        card.addView(engineStatusBanner);
        refreshEngineBanner();

        // Baris Navigasi 5 Tab
        HorizontalScrollView tabScroll = new HorizontalScrollView(context);
        LinearLayout tabRow = new LinearLayout(context);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setPadding(0, 6, 0, 8);

        FrameLayout tabContentHolder = new FrameLayout(context);
        LinearLayout.LayoutParams contentLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        );
        tabContentHolder.setLayoutParams(contentLp);

        final View tabGiveItem = buildGiveItemTab();
        final View tabCombatLan = buildCombatAndWifiLanTab();
        final View tabPlayer = buildPlayerControlsTab();
        final View tabWorldBuilder = buildWorldAndBuilderTab();
        final View tabVisualHud = buildVisualHudTab();

        tabContentHolder.addView(tabGiveItem);
        tabContentHolder.addView(tabCombatLan);
        tabContentHolder.addView(tabPlayer);
        tabContentHolder.addView(tabWorldBuilder);
        tabContentHolder.addView(tabVisualHud);

        Runnable hideAllTabs = () -> {
            tabGiveItem.setVisibility(View.GONE);
            tabCombatLan.setVisibility(View.GONE);
            tabPlayer.setVisibility(View.GONE);
            tabWorldBuilder.setVisibility(View.GONE);
            tabVisualHud.setVisibility(View.GONE);
        };

        Button btnTab1 = createStyledButton("🎒 Give Item (Direct)", "#0284C7");
        Button btnTab2 = createStyledButton("⚔️ Kill Aura & Wi-Fi Teman", "#BE123C");
        Button btnTab3 = createStyledButton("🏃 Player & Bypass Cheat", "#334155");
        Button btnTab4 = createStyledButton("🏗️ Rapid Builder", "#334155");
        Button btnTab5 = createStyledButton("📊 True FPS & HUD", "#334155");

        btnTab1.setOnClickListener(v -> { hideAllTabs.run(); tabGiveItem.setVisibility(View.VISIBLE); });
        btnTab2.setOnClickListener(v -> { hideAllTabs.run(); tabCombatLan.setVisibility(View.VISIBLE); });
        btnTab3.setOnClickListener(v -> { hideAllTabs.run(); tabPlayer.setVisibility(View.VISIBLE); });
        btnTab4.setOnClickListener(v -> { hideAllTabs.run(); tabWorldBuilder.setVisibility(View.VISIBLE); });
        btnTab5.setOnClickListener(v -> { hideAllTabs.run(); tabVisualHud.setVisibility(View.VISIBLE); });

        tabRow.addView(btnTab1);
        tabRow.addView(btnTab2);
        tabRow.addView(btnTab3);
        tabRow.addView(btnTab4);
        tabRow.addView(btnTab5);
        tabScroll.addView(tabRow);
        card.addView(tabScroll);

        hideAllTabs.run();
        tabGiveItem.setVisibility(View.VISIBLE);
        card.addView(tabContentHolder);

        return card;
    }

    /**
     * TAB 1: DIRECT GIVE ITEM
     */
    private View buildGiveItemTab() {
        ScrollView scroll = new ScrollView(context);
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(6, 6, 6, 6);

        layout.addView(createSectionHeader("Klik Item -> Langsung Masuk Inventory via Direct Engine:"));

        String[][] quickItems = {
                {"⚔️ Netherite Sword", "netherite_sword", "1"},
                {"⛏️ Netherite Pickaxe", "netherite_pickaxe", "1"},
                {"🪽 Elytra", "elytra", "1"},
                {"🎆 Firework x64", "firework_rocket", "64"},
                {"🍎 God Apple x64", "enchanted_golden_apple", "64"},
                {"🗿 Totem Undying", "totem_of_undying", "1"},
                {"💎 Diamond Block x64", "diamond_block", "64"},
                {"🧱 Netherite Block x64", "netherite_block", "64"},
                {"🎛️ Command Block", "command_block", "1"},
                {"🚧 Barrier x64", "barrier", "64"},
                {"🔨 Mace (Senjata Baru)", "mace", "1"},
                {"💨 Wind Charge x64", "wind_charge", "64"}
        };

        LinearLayout currentRow = null;
        for (int i = 0; i < quickItems.length; i++) {
            if (i % 3 == 0) {
                currentRow = new LinearLayout(context);
                currentRow.setOrientation(LinearLayout.HORIZONTAL);
                layout.addView(currentRow);
            }
            final String title = quickItems[i][0];
            final String itemId = quickItems[i][1];
            final int count = Integer.parseInt(quickItems[i][2]);

            Button itemBtn = createStyledButton(title, "#1E293B");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(5, 5, 5, 5);
            itemBtn.setLayoutParams(lp);
            itemBtn.setOnClickListener(v -> {
                ToolboxCommandDispatcher.giveItem(context, itemId, count);
                if (!ToolboxWebSocketServer.getInstance().hasConnectedGameEngine()) {
                    toggleMainPanel();
                }
            });
            currentRow.addView(itemBtn);
        }

        layout.addView(createSectionHeader("Ketik Nama Item Kustom & Jumlah:"));
        LinearLayout customRow = new LinearLayout(context);
        customRow.setOrientation(LinearLayout.HORIZONTAL);

        EditText inputItemId = new EditText(context);
        inputItemId.setHint("Contoh: trident atau spyglass");
        inputItemId.setText("trident");
        inputItemId.setTextColor(Color.WHITE);
        inputItemId.setHintTextColor(Color.GRAY);
        LinearLayout.LayoutParams idLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f);
        customRow.addView(inputItemId, idLp);

        EditText inputCount = new EditText(context);
        inputCount.setInputType(InputType.TYPE_CLASS_NUMBER);
        inputCount.setText("1");
        inputCount.setTextColor(Color.WHITE);
        LinearLayout.LayoutParams countLp = new LinearLayout.LayoutParams(120, ViewGroup.LayoutParams.WRAP_CONTENT);
        customRow.addView(inputCount, countLp);

        Button btnGiveCustom = createStyledButton("⚡ Berikan Langsung", "#10B981");
        btnGiveCustom.setOnClickListener(v -> {
            String id = inputItemId.getText().toString().trim();
            int cnt = 1;
            try { cnt = Integer.parseInt(inputCount.getText().toString().trim()); } catch (Exception ignored) {}
            ToolboxCommandDispatcher.giveItem(context, id, cnt);
            if (!ToolboxWebSocketServer.getInstance().hasConnectedGameEngine()) {
                toggleMainPanel();
            }
        });
        customRow.addView(btnGiveCustom);

        layout.addView(customRow);
        scroll.addView(layout);
        return scroll;
    }

    /**
     * TAB 2: KILL AURA & WI-FI / HOTSPOT LAN WORLD TEMAN (Tetap Bekerja Walaupun Cheat Mati!)
     */
    private View buildCombatAndWifiLanTab() {
        ScrollView scroll = new ScrollView(context);
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(6, 6, 6, 6);

        layout.addView(createSectionHeader("📡 Radar Dunia Teman (Wi-Fi / Hotspot LAN Port 19132):"));
        lanStatusTextView = new TextView(context);
        lanStatusTextView.setText(currentLanText);
        lanStatusTextView.setTextColor(Color.parseColor("#4ADE80"));
        lanStatusTextView.setTextSize(12f);
        lanStatusTextView.setPadding(12, 8, 12, 12);
        layout.addView(lanStatusTextView);

        layout.addView(createSectionHeader("⚔️ Kill Aura / Auto-Combat Sweep (Aktif di Dunia Teman Tanpa Cheat):"));

        Button enableAccBtn = createStyledButton("🤖 Buka Izin Aksesibilitas (Wajib untuk Kill Aura & Auto-Inject)", "#0284C7");
        enableAccBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            Toast.makeText(context, "Pilih 'MCPE Toolbox Combat & Direct Engine' lalu aktifkan!", Toast.LENGTH_LONG).show();
        });
        layout.addView(enableAccBtn);

        final TextView cpsLabel = createSectionHeader("Kecepatan Serangan Kill Aura: 12 CPS (Serangan/Detik)");
        layout.addView(cpsLabel);

        SeekBar cpsSeek = new SeekBar(context);
        cpsSeek.setMax(16);
        cpsSeek.setProgress(8); // 4 + 8 = 12 CPS
        cpsSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int cps = 4 + progress;
                cpsLabel.setText("Kecepatan Serangan Kill Aura: " + cps + " CPS (Serangan/Detik)");
                ToolboxAutoService svc = ToolboxAutoService.getInstance();
                if (svc != null) {
                    svc.setAuraConfig(cps, 65);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        layout.addView(cpsSeek);

        final TextView sweepLabel = createSectionHeader("Radius Sapuan Target (Sweep Area): 65 px sekitar Crosshair");
        layout.addView(sweepLabel);

        SeekBar sweepSeek = new SeekBar(context);
        sweepSeek.setMax(180);
        sweepSeek.setProgress(55);
        sweepSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int radius = 10 + progress;
                sweepLabel.setText("Radius Sapuan Target (Sweep Area): " + radius + " px sekitar Crosshair");
                ToolboxAutoService svc = ToolboxAutoService.getInstance();
                if (svc != null) {
                    svc.setAuraConfig(svc.getAuraCps(), radius);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        layout.addView(sweepSeek);

        TextView tip = new TextView(context);
        tip.setText("💡 Gunakan tombol bulat merah [⚔️ OFF/ON] di sebelah kanan layar untuk menyalakan/mematikan Kill Aura secara instan saat bertarung di world Wi-Fi/Hotspot temanmu!");
        tip.setTextColor(Color.parseColor("#CBD5E1"));
        tip.setTextSize(11.5f);
        tip.setPadding(8, 12, 8, 8);
        layout.addView(tip);

        scroll.addView(layout);
        return scroll;
    }

    /**
     * TAB 3: PLAYER & BYPASS CHEAT (level.dat Patcher)
     */
    private View buildPlayerControlsTab() {
        ScrollView scroll = new ScrollView(context);
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(6, 6, 6, 6);

        layout.addView(createSectionHeader("🔓 Buka Paksa Kunci Cheat di World Survival (level.dat Binary Patcher):"));
        LinearLayout patchRow = new LinearLayout(context);
        patchRow.setOrientation(LinearLayout.HORIZONTAL);

        Button btnUnlockCheat = createStyledButton("🔓 Paksa Aktifkan Cheat di Semua World", "#D97706");
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p1.setMargins(5, 5, 5, 5);
        btnUnlockCheat.setLayoutParams(p1);
        btnUnlockCheat.setOnClickListener(v -> {
            int count = LevelDatPatcher.forceUnlockCheatsInAllLocalWorlds(-1);
            Toast.makeText(context, "Berhasil membuka paksa commandsEnabled di " + count + " world lokal!", Toast.LENGTH_LONG).show();
        });
        patchRow.addView(btnUnlockCheat);

        Button btnForceCreative = createStyledButton("🎨 Paksa Ubah level.dat ke Creative", "#7C3AED");
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p2.setMargins(5, 5, 5, 5);
        btnForceCreative.setLayoutParams(p2);
        btnForceCreative.setOnClickListener(v -> {
            int count = LevelDatPatcher.forceUnlockCheatsInAllLocalWorlds(1);
            Toast.makeText(context, "Berhasil mengubah level.dat ke Creative di " + count + " world!", Toast.LENGTH_LONG).show();
        });
        patchRow.addView(btnForceCreative);
        layout.addView(patchRow);

        layout.addView(createSectionHeader("Ubah Gamemode Instan (Direct Engine):"));
        LinearLayout gmRow = new LinearLayout(context);
        gmRow.setOrientation(LinearLayout.HORIZONTAL);

        String[][] modes = {
                {"⚔️ Survival", "s"},
                {"🎨 Creative", "c"},
                {"👻 Spectator", "spectator"},
                {"🗺️ Adventure", "a"}
        };
        for (String[] m : modes) {
            Button b = createStyledButton(m[0], "#0369A1");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(5, 5, 5, 5);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> ToolboxCommandDispatcher.setGamemode(context, m[1]));
            gmRow.addView(b);
        }
        layout.addView(gmRow);

        layout.addView(createSectionHeader("Kemampuan Karakter (Abilities & Efek Tanpa Partikel):"));

        layout.addView(createToggleSwitch("☀️ Fullbright (Night Vision Terang Maksimal)", isFullbright, checked -> {
            isFullbright = checked;
            ToolboxCommandDispatcher.setPlayerAbility(context, "fullbright", checked, 1);
            updateHudText();
        }));

        layout.addView(createToggleSwitch("🚀 Speed Boost Lari Cepat (Speed IV)", isSpeedBoost, checked -> {
            isSpeedBoost = checked;
            ToolboxCommandDispatcher.setPlayerAbility(context, "speed_boost", checked, 4);
            updateHudText();
        }));

        layout.addView(createToggleSwitch("🛡️ God Mode (Kebal Semua Serangan / Resistance 255)", isGodMode, checked -> {
            isGodMode = checked;
            ToolboxCommandDispatcher.setPlayerAbility(context, "god_mode", checked, 255);
            updateHudText();
        }));

        layout.addView(createToggleSwitch("⛏️ Insta-Mine / Fast Break (Haste X)", false, checked ->
                ToolboxCommandDispatcher.setPlayerAbility(context, "instamine", checked, 10)
        ));

        layout.addView(createToggleSwitch("🪽 Aktifkan Terbang di Survival (/ability mayfly)", false, checked ->
                ToolboxCommandDispatcher.setPlayerAbility(context, "fly_levitation", checked, 1)
        ));

        scroll.addView(layout);
        return scroll;
    }

    /**
     * TAB 4: WORLD & RAPID BUILDER
     */
    private View buildWorldAndBuilderTab() {
        ScrollView scroll = new ScrollView(context);
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(6, 6, 6, 6);

        layout.addView(createSectionHeader("Kontrol Waktu & Cuaca Dunia:"));
        LinearLayout timeRow = new LinearLayout(context);
        timeRow.setOrientation(LinearLayout.HORIZONTAL);

        String[][] times = {{"🌅 Pagi", "sunrise"}, {"☀️ Siang", "noon"}, {"🌇 Sore", "sunset"}, {"🌙 Malam", "midnight"}};
        for (String[] t : times) {
            Button b = createStyledButton(t[0], "#1D4ED8");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(5, 5, 5, 5);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> ToolboxCommandDispatcher.setWorldEnvironment(context, "time", t[1]));
            timeRow.addView(b);
        }
        layout.addView(timeRow);

        LinearLayout weatherRow = new LinearLayout(context);
        weatherRow.setOrientation(LinearLayout.HORIZONTAL);
        String[][] weathers = {{"🌤️ Cerah", "clear"}, {"🌧️ Hujan", "rain"}, {"⛈️ Badai", "thunder"}, {"🧹 Hapus Item Lag", "clear_lag"}};
        for (String[] w : weathers) {
            Button b = createStyledButton(w[0], "#334155");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(5, 5, 5, 5);
            b.setLayoutParams(lp);
            b.setOnClickListener(v ->
                    ToolboxCommandDispatcher.setWorldEnvironment(context, "clear_lag".equals(w[1]) ? "lag" : "weather", w[1])
            );
            weatherRow.addView(b);
        }
        layout.addView(weatherRow);

        final TextView selectedBlockLabel = createSectionHeader("🧱 Material Rapid Builder Saat Ini: " + selectedBuildBlock);
        layout.addView(selectedBlockLabel);

        HorizontalScrollView blockScroll = new HorizontalScrollView(context);
        LinearLayout blockRow = new LinearLayout(context);
        blockRow.setOrientation(LinearLayout.HORIZONTAL);
        String[][] blockChoices = {
                {"🧱 Stone Bricks", "stone_bricks"},
                {"🏛️ Quartz", "quartz_block"},
                {"🪵 Oak Planks", "oak_planks"},
                {"🪟 Glass", "glass"},
                {"🟣 Obsidian", "obsidian"},
                {"💎 Diamond Block", "diamond_block"}
        };
        for (String[] bc : blockChoices) {
            Button b = createStyledButton(bc[0], "#475569");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
            lp.setMargins(5, 5, 5, 5);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                selectedBuildBlock = bc[1];
                selectedBlockLabel.setText("🧱 Material Rapid Builder Saat Ini: " + selectedBuildBlock);
            });
            blockRow.addView(b);
        }
        blockScroll.addView(blockRow);
        layout.addView(blockScroll);

        layout.addView(createSectionHeader("🏗️ Bangun Otomatis di Sekitar Posisi Karaktermu:"));
        LinearLayout buildShapesRow = new LinearLayout(context);
        buildShapesRow.setOrientation(LinearLayout.HORIZONTAL);

        String[][] shapes = {
                {"⬛ Lantai 9x9", "platform"},
                {"🏰 Benteng Dinding", "walls"},
                {"🏠 Ruangan Hollow", "hollow_box"},
                {"🧹 Ratakan Area (Air)", "clear_area"}
        };
        for (String[] s : shapes) {
            Button b = createStyledButton(s[0], "#0D9488");
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(5, 5, 5, 5);
            b.setLayoutParams(lp);
            b.setOnClickListener(v ->
                    ToolboxCommandDispatcher.executeRapidBuild(context, s[1], selectedBuildBlock, buildRadius)
            );
            buildShapesRow.addView(b);
        }
        layout.addView(buildShapesRow);

        scroll.addView(layout);
        return scroll;
    }

    /**
     * TAB 5: TRUE FPS & HUD TELEMETRY
     */
    private View buildVisualHudTab() {
        ScrollView scroll = new ScrollView(context);
        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(6, 6, 6, 6);

        layout.addView(createSectionHeader("Pengaturan Telemetri True FPS (Frame-Time ms & 1% Low) & Crosshair:"));

        layout.addView(createToggleSwitch("📊 Tampilkan HUD True FPS + Frame-Time (ms) + 1% Low", true, checked -> {
            if (hudWindowView != null) {
                hudWindowView.setVisibility(checked ? View.VISIBLE : View.GONE);
            }
        }));

        layout.addView(createToggleSwitch("🎯 Tampilkan Crosshair Pembidik Tengah Layar (Bantu Kill Aura)", isCrosshairActive, checked -> {
            isCrosshairActive = checked;
            if (crosshairView != null) {
                crosshairView.setVisibility(checked ? View.VISIBLE : View.GONE);
            }
        }));

        scroll.addView(layout);
        return scroll;
    }

    private TextView createSectionHeader(String text) {
        TextView tv = new TextView(context);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#93C5FD"));
        tv.setTextSize(12f);
        tv.setPadding(4, 12, 4, 6);
        return tv;
    }

    private Button createStyledButton(String text, String hexColor) {
        Button btn = new Button(context);
        btn.setText(text);
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(11f);
        btn.setAllCaps(false);
        btn.setPadding(16, 10, 16, 10);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(hexColor));
        bg.setCornerRadius(14f);
        btn.setBackground(bg);
        return btn;
    }

    public interface OnToggleListener {
        void onChanged(boolean isChecked);
    }

    private Switch createToggleSwitch(String label, boolean initialValue, OnToggleListener listener) {
        Switch sw = new Switch(context);
        sw.setText(label);
        sw.setTextColor(Color.WHITE);
        sw.setTextSize(12f);
        sw.setChecked(initialValue);
        sw.setPadding(10, 10, 10, 10);
        sw.setOnCheckedChangeListener((buttonView, isChecked) -> listener.onChanged(isChecked));
        return sw;
    }
}
