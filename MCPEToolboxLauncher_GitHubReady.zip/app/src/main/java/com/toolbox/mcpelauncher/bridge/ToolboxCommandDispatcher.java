package com.toolbox.mcpelauncher.bridge;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

public class ToolboxCommandDispatcher {
    private static final String TAG = "ToolboxDispatcher";
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());
    private static String sLastCommand = "/give @s netherite_sword 1";

    public static String getLastCommand() {
        return sLastCommand;
    }

    public static void giveItem(Context context, String itemId, int amount, boolean autoEnchant) {
        String cleanId = itemId.startsWith("minecraft:") ? itemId.substring(10) : itemId;
        String cmd = "/give @s " + cleanId + " " + Math.max(1, Math.min(64, amount));
        executeAndCopyCommand(context, cmd, "Item siap: " + cmd + " (Otomatis disalin ke Clipboard!)");
    }

    public static void runMacroKit(Context context, String kitName) {
        String cmd;
        if ("netherite_kit".equals(kitName)) {
            cmd = "/function toolbox/kit_netherite";
        } else if ("builder_kit".equals(kitName)) {
            cmd = "/give @s command_block 1";
        } else {
            cmd = "/give @s enchanted_golden_apple 64";
        }
        executeAndCopyCommand(context, cmd, "Kit siap: " + cmd + " (Disalin ke Clipboard!)");
    }

    public static void setPlayerAbility(Context context, String abilityType, boolean enabled, int amplifier) {
        String cmd;
        switch (abilityType) {
            case "fullbright":
                cmd = enabled
                        ? "/effect @s night_vision 999999 1 true"
                        : "/effect @s night_vision 0 0 true";
                break;
            case "speed_boost":
                cmd = enabled
                        ? "/effect @s speed 999999 " + amplifier + " true"
                        : "/effect @s speed 0 0 true";
                break;
            case "god_mode":
                cmd = enabled
                        ? "/effect @s resistance 999999 255 true"
                        : "/effect @s clear";
                break;
            case "instamine":
                cmd = enabled
                        ? "/effect @s haste 999999 " + amplifier + " true"
                        : "/effect @s haste 0 0 true";
                break;
            case "fly_levitation":
                cmd = enabled
                        ? "/ability @s mayfly true"
                        : "/effect @s slow_falling 30 1 true";
                break;
            default:
                cmd = "/effect @s regeneration 60 5 true";
                break;
        }
        executeAndCopyCommand(context, cmd, "Ability (" + abilityType + "): " + cmd);
    }

    public static void setGamemode(Context context, String mode) {
        String cmd = "/gamemode " + mode + " @s";
        executeAndCopyCommand(context, cmd, "Gamemode: " + cmd + " (Disalin ke Clipboard!)");
    }

    public static void setWorldEnvironment(Context context, String envType, String value) {
        String cmd;
        if ("time".equals(envType)) {
            cmd = "/time set " + value;
        } else if ("weather".equals(envType)) {
            cmd = "/weather " + value;
        } else {
            cmd = "/kill @e[type=item]";
        }
        executeAndCopyCommand(context, cmd, "Dunia: " + cmd + " (Disalin ke Clipboard!)");
    }

    public static void executeRapidBuild(Context context, String shape, String blockId, int r) {
        String cleanBlock = blockId.startsWith("minecraft:") ? blockId.substring(10) : blockId;
        String cmd;
        if ("platform".equals(shape)) {
            cmd = "/fill ~-" + r + " ~-1 ~-" + r + " ~" + r + " ~-1 ~" + r + " " + cleanBlock;
        } else if ("walls".equals(shape)) {
            cmd = "/fill ~-" + r + " ~ ~-" + r + " ~" + r + " ~3 ~" + r + " " + cleanBlock + " outline";
        } else if ("hollow_box".equals(shape)) {
            cmd = "/fill ~-" + r + " ~-1 ~-" + r + " ~" + r + " ~4 ~" + r + " " + cleanBlock + " hollow";
        } else {
            cmd = "/fill ~-" + r + " ~ ~-" + r + " ~" + r + " ~" + r + " ~" + r + " air";
        }
        executeAndCopyCommand(context, cmd, "RapidBuild: " + cmd + " (Disalin ke Clipboard!)");
    }

    public static void executeAndCopyCommand(Context context, String command, String toastMsg) {
        sLastCommand = command;
        Log.i(TAG, "Menyalin & menyiapkan perintah: " + command);
        ToolboxBridgeInstaller.writeCommandStateFile(context, command);

        MAIN_HANDLER.post(() -> {
            try {
                ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null) {
                    ClipData clip = ClipData.newPlainText("MCPE Toolbox Command", command);
                    clipboard.setPrimaryClip(clip);
                }
            } catch (Exception e) {
                Log.e(TAG, "Clipboard error", e);
            }
            Toast.makeText(context, "📋 " + toastMsg + "\n👉 Buka Chat MCPE lalu Paste!", Toast.LENGTH_SHORT).show();
        });
    }
}
