package com.toolbox.mcpelauncher.bridge;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import com.toolbox.mcpelauncher.automation.ToolboxAutoService;

public class ToolboxCommandDispatcher {
    private static final Handler MAIN_HANDLER = new Handler(Looper.getMainLooper());
    private static String sLastStatus = "Siap mengeksekusi langsung ke dunia";

    public static String getLastStatus() {
        return sLastStatus;
    }

    public static void giveItem(Context context, String itemId, int amount) {
        String cleanId = itemId.startsWith("minecraft:") ? itemId.substring(10) : itemId;
        String cmd = "/give @s " + cleanId + " " + Math.max(1, Math.min(64, amount));
        executeDirectAction(context, cmd, "Memberikan " + amount + "x " + cleanId);
    }

    public static void setPlayerAbility(Context context, String abilityType, boolean enabled, int amplifier) {
        String cmd;
        switch (abilityType) {
            case "fullbright":
                cmd = enabled
                        ? "/effect @s night_vision 999999 1 true"
                        : "/effect @s night_vision 0 0 true";
                break;
            case "speed_boost":
                cmd = enabled
                        ? "/effect @s speed 999999 " + amplifier + " true"
                        : "/effect @s speed 0 0 true";
                break;
            case "god_mode":
                cmd = enabled
                        ? "/effect @s resistance 999999 255 true"
                        : "/effect @s clear";
                break;
            case "instamine":
                cmd = enabled
                        ? "/effect @s haste 999999 " + amplifier + " true"
                        : "/effect @s haste 0 0 true";
                break;
            case "fly_levitation":
                cmd = enabled
                        ? "/ability @s mayfly true"
                        : "/effect @s slow_falling 30 1 true";
                break;
            default:
                cmd = "/effect @s regeneration 60 5 true";
                break;
        }
        executeDirectAction(context, cmd, "Ability " + abilityType + ": " + (enabled ? "ON" : "OFF"));
    }

    public static void setGamemode(Context context, String mode) {
        String cmd = "/gamemode " + mode + " @s";
        executeDirectAction(context, cmd, "Gamemode diubah ke " + mode.toUpperCase());
    }

    public static void setWorldEnvironment(Context context, String envType, String value) {
        String cmd;
        if ("time".equals(envType)) {
            cmd = "/time set " + value;
        } else if ("weather".equals(envType)) {
            cmd = "/weather " + value;
        } else {
            cmd = "/kill @e[type=item]";
        }
        executeDirectAction(context, cmd, "Dunia diubah: " + envType + " -> " + value);
    }

    public static void executeRapidBuild(Context context, String shape, String blockId, int r) {
        String cleanBlock = blockId.startsWith("minecraft:") ? blockId.substring(10) : blockId;
        String cmd;
        if ("platform".equals(shape)) {
            cmd = "/fill ~-" + r + " ~-1 ~-" + r + " ~" + r + " ~-1 ~" + r + " " + cleanBlock;
        } else if ("walls".equals(shape)) {
            cmd = "/fill ~-" + r + " ~ ~-" + r + " ~" + r + " ~3 ~" + r + " " + cleanBlock + " outline";
        } else if ("hollow_box".equals(shape)) {
            cmd = "/fill ~-" + r + " ~-1 ~-" + r + " ~" + r + " ~4 ~" + r + " " + cleanBlock + " hollow";
        } else {
            cmd = "/fill ~-" + r + " ~ ~-" + r + " ~" + r + " ~" + r + " ~" + r + " air";
        }
        executeDirectAction(context, cmd, "RapidBuild: " + shape + " (" + cleanBlock + ")");
    }

    public static void connectDirectEngineSocket(Context context) {
        ToolboxWebSocketServer.getInstance().startServer();
        String wsCmd = "/wsserver 127.0.0.1:19131";
        copyToClipboard(context, wsCmd);
        ToolboxAutoService autoSvc = ToolboxAutoService.getInstance();
        if (autoSvc != null) {
            autoSvc.autoInjectCommandIntoGame(wsCmd);
            Toast.makeText(context, "⚡ Menghubungkan Direct Engine secara otomatis...", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "⚡ Server Direct Engine siap! Ketik/Paste sekali di dunia: /wsserver 127.0.0.1:19131", Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Mengeksekusi aksi langsung ke dunia:
     * 1. Jika Direct Engine WebSocket terhubung -> Langsung dieksekusi di memori dunia dalam 1ms TANPA buka chat!
     * 2. Jika Accessibility Auto-Service aktif -> Otomatis diinjeksikan oleh sistem tanpa perlu ketik/paste manual!
     */
    public static void executeDirectAction(Context context, String command, String description) {
        copyToClipboard(context, command);

        boolean sentViaSocket = ToolboxWebSocketServer.getInstance().sendDirectEngineAction(command);
        if (sentViaSocket) {
            sLastStatus = "🟢 Direct Engine Sukses: " + description;
            MAIN_HANDLER.post(() ->
                    Toast.makeText(context, "⚡ [Direct Engine] " + description, Toast.LENGTH_SHORT).show()
            );
            return;
        }

        ToolboxAutoService autoSvc = ToolboxAutoService.getInstance();
        if (autoSvc != null) {
            sLastStatus = "🤖 Auto-Inject Sukses: " + description;
            autoSvc.autoInjectCommandIntoGame(command);
            MAIN_HANDLER.post(() ->
                    Toast.makeText(context, "🤖 [Auto-Execute] " + description, Toast.LENGTH_SHORT).show()
            );
            return;
        }

        sLastStatus = "📋 Siap Eksekusi: " + command + " (Hubungkan Direct Engine di Tab 1 agar otomatis!)";
        MAIN_HANDLER.post(() ->
                Toast.makeText(context, "⚡ " + description + " (Aktifkan Direct Engine / Accessibility agar otomatis tanpa paste!)", Toast.LENGTH_SHORT).show()
        );
    }

    private static void copyToClipboard(Context context, String text) {
        MAIN_HANDLER.post(() -> {
            try {
                ClipboardManager cb = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cb != null) {
                    cb.setPrimaryClip(ClipData.newPlainText("Toolbox Direct", text));
                }
            } catch (Exception ignored) {
            }
        });
    }
}
