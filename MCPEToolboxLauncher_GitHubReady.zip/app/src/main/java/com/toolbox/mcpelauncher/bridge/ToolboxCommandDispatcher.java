package com.toolbox.mcpelauncher.bridge;

import android.app.Activity;
import android.app.Instrumentation;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Mengirimkan aksi dari Floating Toolbox UI ke mesin Minecraft yang sedang berjalan.
 * Mendukung 2 jalur sekaligus:
 * 1. Jalur Native JNI (untuk Zoom kamera instan, Fullbright, & antrean C++).
 * 2. Jalur ScriptEvent / Command Injection (/scriptevent toolbox:cmd {...}) yang 100% tahan update versi Play Store.
 */
public class ToolboxCommandDispatcher {
    private static final String TAG = "ToolboxDispatcher";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    public static native void nativeSetFullbright(boolean enabled);
    public static native void nativeSetZoomFactor(float zoomFactor);
    public static native void nativeQueueToolboxCommand(String command);

    public static void giveItem(Activity activity, String itemId, int amount, int enchantLevel) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("action", "give");
            payload.put("item", itemId);
            payload.put("count", amount);
            payload.put("enchantLevel", enchantLevel);
            dispatchToolboxAction(activity, payload, "Memberikan " + amount + "x " + itemId);
        } catch (Exception e) {
            Log.e(TAG, "Error giveItem", e);
        }
    }

    public static void setPlayerAbility(Activity activity, String abilityType, boolean enabled, int amplifier) {
        try {
            if ("fullbright".equals(abilityType)) {
                nativeSetFullbright(enabled);
            }
            JSONObject payload = new JSONObject();
            payload.put("action", "ability");
            payload.put("type", abilityType);
            payload.put("enabled", enabled);
            payload.put("amplifier", amplifier);
            dispatchToolboxAction(activity, payload, "Fitur " + abilityType + ": " + (enabled ? "ON" : "OFF"));
        } catch (Exception e) {
            Log.e(TAG, "Error setPlayerAbility", e);
        }
    }

    public static void setGamemode(Activity activity, String mode) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("action", "gamemode");
            payload.put("mode", mode);
            dispatchToolboxAction(activity, payload, "Gamemode diubah ke " + mode.toUpperCase());
        } catch (Exception e) {
            Log.e(TAG, "Error setGamemode", e);
        }
    }

    public static void setWorldEnvironment(Activity activity, String envType, String value) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("action", "environment");
            payload.put("envType", envType);
            payload.put("value", value);
            dispatchToolboxAction(activity, payload, "Mengatur " + envType + " -> " + value);
        } catch (Exception e) {
            Log.e(TAG, "Error setWorldEnvironment", e);
        }
    }

    public static void executeRapidBuild(Activity activity, String shape, String blockId, int radius) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("action", "build");
            payload.put("shape", shape);
            payload.put("block", blockId);
            payload.put("radius", radius);
            dispatchToolboxAction(activity, payload, "WorldBuilder: " + shape + " (" + blockId + ")");
        } catch (Exception e) {
            Log.e(TAG, "Error executeRapidBuild", e);
        }
    }

    private static void dispatchToolboxAction(Activity activity, JSONObject payload, String toastMsg) {
        String rawCommand = "/scriptevent toolbox:cmd " + payload.toString();
        nativeQueueToolboxCommand(rawCommand);
        ToolboxBridgeInstaller.writeCommandStateFile(activity, payload.toString());

        // Simulasikan pengiriman event ke dalam aktivitas jika diizinkan
        EXECUTOR.execute(() -> {
            try {
                Instrumentation inst = new Instrumentation();
                // Catatan: Jika pengguna mengaktifkan jembatan ScriptEvent di world, perintah langsung dieksekusi
                Log.i(TAG, "Mengirim perintah ke jembatan: " + rawCommand);
            } catch (Exception ignored) {
            }
        });

        activity.runOnUiThread(() ->
                Toast.makeText(activity, "[Toolbox] " + toastMsg, Toast.LENGTH_SHORT).show()
        );
    }
}
