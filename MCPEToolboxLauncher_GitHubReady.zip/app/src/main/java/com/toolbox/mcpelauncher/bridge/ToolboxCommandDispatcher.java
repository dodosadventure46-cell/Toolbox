package com.toolbox.mcpelauncher.bridge;

import android.app.Activity;
import android.util.Log;
import android.widget.Toast;

import com.toolbox.mcpelauncher.core.MinecraftPackageLoader;

import org.json.JSONObject;

public class ToolboxCommandDispatcher {
    private static final String TAG = "ToolboxDispatcher";

    public static native void nativeSetFullbright(boolean enabled);
    public static native void nativeSetZoomFactor(float zoomFactor);
    public static native void nativeQueueToolboxCommand(String command);

    public static void safeSetFullbright(boolean enabled) {
        if (MinecraftPackageLoader.isNativeBridgeAvailable()) {
            try { nativeSetFullbright(enabled); } catch (Throwable ignored) {}
        }
    }

    public static void safeSetZoomFactor(float zoomFactor) {
        if (MinecraftPackageLoader.isNativeBridgeAvailable()) {
            try { nativeSetZoomFactor(zoomFactor); } catch (Throwable ignored) {}
        }
    }

    public static void giveItem(Activity activity, String itemId, int amount, int enchantLevel) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("action", "give");
            payload.put("item", itemId);
            payload.put("count", amount);
            payload.put("enchantLevel", enchantLevel);
            dispatchToolboxAction(activity, payload, "Memberikan " + amount + "x " + itemId);
        } catch (Exception e) {
            Log.e(TAG, "Error giveItem", e);
        }
    }

    public static void setPlayerAbility(Activity activity, String abilityType, boolean enabled, int amplifier) {
        try {
            if ("fullbright".equals(abilityType)) {
                safeSetFullbright(enabled);
            }
            JSONObject payload = new JSONObject();
            payload.put("action", "ability");
            payload.put("type", abilityType);
            payload.put("enabled", enabled);
            payload.put("amplifier", amplifier);
            dispatchToolboxAction(activity, payload, "Fitur " + abilityType + ": " + (enabled ? "ON" : "OFF"));
        } catch (Exception e) {
            Log.e(TAG, "Error setPlayerAbility", e);
        }
    }

    public static void setGamemode(Activity activity, String mode) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("action", "gamemode");
            payload.put("mode", mode);
            dispatchToolboxAction(activity, payload, "Gamemode diubah ke " + mode.toUpperCase());
        } catch (Exception e) {
            Log.e(TAG, "Error setGamemode", e);
        }
    }

    public static void setWorldEnvironment(Activity activity, String envType, String value) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("action", "environment");
            payload.put("envType", envType);
            payload.put("value", value);
            dispatchToolboxAction(activity, payload, "Mengatur " + envType + " -> " + value);
        } catch (Exception e) {
            Log.e(TAG, "Error setWorldEnvironment", e);
        }
    }

    public static void executeRapidBuild(Activity activity, String shape, String blockId, int radius) {
        try {
            JSONObject payload = new JSONObject();
            payload.put("action", "build");
            payload.put("shape", shape);
            payload.put("block", blockId);
            payload.put("radius", radius);
            dispatchToolboxAction(activity, payload, "WorldBuilder: " + shape + " (" + blockId + ")");
        } catch (Exception e) {
            Log.e(TAG, "Error executeRapidBuild", e);
        }
    }

    private static void dispatchToolboxAction(Activity activity, JSONObject payload, String toastMsg) {
        String rawCommand = "/scriptevent toolbox:cmd " + payload.toString();
        if (MinecraftPackageLoader.isNativeBridgeAvailable()) {
            try { nativeQueueToolboxCommand(rawCommand); } catch (Throwable ignored) {}
        }
        ToolboxBridgeInstaller.writeCommandStateFile(activity, payload.toString());

        activity.runOnUiThread(() ->
                Toast.makeText(activity, "[Toolbox] " + toastMsg, Toast.LENGTH_SHORT).show()
        );
    }
}
