package com.toolbox.mcpelauncher.core;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.util.Log;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import dalvik.system.PathClassLoader;

public class MinecraftPackageLoader {
    private static final String TAG = "MCPELoader";
    public static final String MCPE_PACKAGE_NAME = "com.mojang.minecraftpe";
    private static boolean sNativeBridgeAvailable = false;

    static {
        try {
            System.loadLibrary("toolbox_bridge");
            sNativeBridgeAvailable = true;
        } catch (Throwable t) {
            Log.w(TAG, "Menggunakan fallback Java System.load karena libtoolbox_bridge.so belum aktif: " + t.getMessage());
        }
    }

    public static native boolean nativeLoadMinecraftLibraries(String nativeLibDir);

    public static boolean isNativeBridgeAvailable() {
        return sNativeBridgeAvailable;
    }

    public static class LoadedMinecraftEnv {
        public final String versionName;
        public final long versionCode;
        public final String nativeLibraryDir;
        public final List<String> apkPaths;
        public final ClassLoader classLoader;
        public final AssetManager assetManager;
        public final Resources resources;

        public LoadedMinecraftEnv(
                String versionName,
                long versionCode,
                String nativeLibraryDir,
                List<String> apkPaths,
                ClassLoader classLoader,
                AssetManager assetManager,
                Resources resources) {
            this.versionName = versionName;
            this.versionCode = versionCode;
            this.nativeLibraryDir = nativeLibraryDir;
            this.apkPaths = apkPaths;
            this.classLoader = classLoader;
            this.assetManager = assetManager;
            this.resources = resources;
        }
    }

    public static PackageInfo getInstalledMinecraftInfo(Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            return pm.getPackageInfo(MCPE_PACKAGE_NAME, PackageManager.GET_META_DATA);
        } catch (PackageManager.NameNotFoundException e) {
            return null;
        }
    }

    public static LoadedMinecraftEnv prepareMinecraftEnvironment(Context hostContext) throws Exception {
        PackageManager pm = hostContext.getPackageManager();
        PackageInfo pkgInfo = pm.getPackageInfo(MCPE_PACKAGE_NAME, 0);
        ApplicationInfo appInfo = pkgInfo.applicationInfo;

        List<String> allApkPaths = new ArrayList<>();
        allApkPaths.add(appInfo.sourceDir);
        if (appInfo.splitPublicSourceDirs != null) {
            for (String splitPath : appInfo.splitPublicSourceDirs) {
                allApkPaths.add(splitPath);
            }
        }

        String joinedDexPath = String.join(File.pathSeparator, allApkPaths);
        String nativeLibDir = appInfo.nativeLibraryDir;

        Log.i(TAG, "Versi MCPE Terdeteksi: " + pkgInfo.versionName + " (" + pkgInfo.getLongVersionCode() + ")");

        PathClassLoader mcClassLoader = new PathClassLoader(
                joinedDexPath,
                nativeLibDir,
                hostContext.getClassLoader()
        );

        Constructor<AssetManager> assetCtor = AssetManager.class.getDeclaredConstructor();
        assetCtor.setAccessible(true);
        AssetManager assetManager = assetCtor.newInstance();

        Method addAssetPath = AssetManager.class.getDeclaredMethod("addAssetPath", String.class);
        addAssetPath.setAccessible(true);
        for (String apkPath : allApkPaths) {
            addAssetPath.invoke(assetManager, apkPath);
        }

        Resources hostRes = hostContext.getResources();
        @SuppressWarnings("deprecation")
        Resources mcResources = new Resources(
                assetManager,
                hostRes.getDisplayMetrics(),
                hostRes.getConfiguration()
        );

        boolean nativeLoaded = false;
        if (sNativeBridgeAvailable) {
            nativeLoaded = nativeLoadMinecraftLibraries(nativeLibDir);
        } else {
            String[] libs = {
                "libc++_shared.so",
                "libfmod.so",
                "libmaesdk.so",
                "libMediaDecoders_Android.so",
                "libminecraftpe.so"
            };
            for (String lib : libs) {
                File f = new File(nativeLibDir, lib);
                if (f.exists()) {
                    System.load(f.getAbsolutePath());
                    if ("libminecraftpe.so".equals(lib)) {
                        nativeLoaded = true;
                    }
                }
            }
        }

        if (!nativeLoaded) {
            throw new IllegalStateException("Gagal memuat libminecraftpe.so dari: " + nativeLibDir);
        }

        return new LoadedMinecraftEnv(
                pkgInfo.versionName,
                pkgInfo.getLongVersionCode(),
                nativeLibDir,
                allApkPaths,
                mcClassLoader,
                assetManager,
                mcResources
        );
    }
}
