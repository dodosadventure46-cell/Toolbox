package com.toolbox.mcpelauncher.core;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.widget.Toast;

public class MinecraftPackageLoader {
    public static final String MCPE_PACKAGE_NAME = "com.mojang.minecraftpe";

    public static PackageInfo getInstalledMinecraftInfo(Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            return pm.getPackageInfo(MCPE_PACKAGE_NAME, 0);
        } catch (PackageManager.NameNotFoundException e) {
            return null;
        }
    }

    /**
     * Meluncurkan aplikasi Minecraft Bedrock asli dari Google Play Store
     * setelah ToolboxFloatingService aktif di layar (100% bebas Force Close / SIGABRT).
     */
    public static boolean launchOfficialMinecraft(Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            Intent launchIntent = pm.getLaunchIntentForPackage(MCPE_PACKAGE_NAME);
            if (launchIntent == null) {
                Toast.makeText(context, "Aplikasi Minecraft tidak ditemukan!", Toast.LENGTH_LONG).show();
                return false;
            }
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            context.startActivity(launchIntent);
            return true;
        } catch (Exception e) {
            Toast.makeText(context, "Gagal membuka Minecraft: " + e.getMessage(), Toast.LENGTH_LONG).show();
            return false;
        }
    }
}
