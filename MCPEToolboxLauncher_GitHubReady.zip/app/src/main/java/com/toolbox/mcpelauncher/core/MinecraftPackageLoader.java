package com.toolbox.mcpelauncher.core;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.util.Log;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import dalvik.system.PathClassLoader;

/**
 * Mengelola pembacaan APK Minecraft Bedrock (com.mojang.minecraftpe) yang terinstal
 * dari Google Play Store secara dinamis tanpa memodifikasi file APK asli.
 */
public class MinecraftPackageLoader {
    private static final String TAG = "MCPELoader";
    public static final String MCPE_PACKAGE_NAME = "com.mojang.minecraftpe";

    static {
        System.loadLibrary("toolbox_bridge");
    }

    public static native boolean nativeLoadMinecraftLibraries(String nativeLibDir);

    public static class LoadedMinecraftEnv {
        public final String versionName;
        public final long versionCode;
        public final String nativeLibraryDir;
        public final List<String> apkPaths;
        public final ClassLoader classLoader;
        public final AssetManager assetManager;
        public final Resources resources;

        public LoadedMinecraftEnv(
                String versionName,
                long versionCode,
                String nativeLibraryDir,
                List<String> apkPaths,
                ClassLoader classLoader,
                AssetManager assetManager,
                Resources resources) {
            this.versionName = versionName;
            this.versionCode = versionCode;
            this.nativeLibraryDir = nativeLibraryDir;
            this.apkPaths = apkPaths;
            this.classLoader = classLoader;
            this.assetManager = assetManager;
            this.resources = resources;
        }
    }

    /**
     * Memeriksa apakah Minecraft Bedrock terinstal dan mengambil informasi versinya.
     */
    public static PackageInfo getInstalledMinecraftInfo(Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            return pm.getPackageInfo(MCPE_PACKAGE_NAME, PackageManager.GET_META_DATA);
        } catch (PackageManager.NameNotFoundException e) {
            return null;
        }
    }

    /**
     * Memuat seluruh Split APK (base.apk + split_config.arm64_v8a.apk + aset) dan pustaka C++
     * dari instalasi Google Play Store ke dalam proses Launcher kita.
     */
    public static LoadedMinecraftEnv prepareMinecraftEnvironment(Context hostContext) throws Exception {
        PackageManager pm = hostContext.getPackageManager();
        PackageInfo pkgInfo = pm.getPackageInfo(MCPE_PACKAGE_NAME, 0);
        ApplicationInfo appInfo = pkgInfo.applicationInfo;

        List<String> allApkPaths = new ArrayList<>();
        allApkPaths.add(appInfo.sourceDir);
        if (appInfo.splitPublicSourceDirs != null) {
            for (String splitPath : appInfo.splitPublicSourceDirs) {
                allApkPaths.add(splitPath);
            }
        }

        String joinedDexPath = String.join(File.pathSeparator, allApkPaths);
        String nativeLibDir = appInfo.nativeLibraryDir;

        Log.i(TAG, "Versi MCPE Terdeteksi: " + pkgInfo.versionName + " (" + pkgInfo.getLongVersionCode() + ")");
        Log.i(TAG, "Jalur Native Library: " + nativeLibDir);

        // 1. Buat PathClassLoader yang memuat bytecode Java milik Minecraft
        PathClassLoader mcClassLoader = new PathClassLoader(
                joinedDexPath,
                nativeLibDir,
                hostContext.getClassLoader()
        );

        // 2. Buat AssetManager gabungan agar tekstur, shader RenderDragon, dan UI OreUI termuat utuh
        AssetManager assetManager = AssetManager.class.newInstance();
        Method addAssetPath = AssetManager.class.getDeclaredMethod("addAssetPath", String.class);
        addAssetPath.setAccessible(true);
        for (String apkPath : allApkPaths) {
            addAssetPath.invoke(assetManager, apkPath);
        }

        Resources hostRes = hostContext.getResources();
        Resources mcResources = new Resources(
                assetManager,
                hostRes.getDisplayMetrics(),
                hostRes.getConfiguration()
        );

        // 3. Muat pustaka C++ (libc++_shared.so, libfmod.so, libminecraftpe.so) lewat NDK dlopen
        boolean nativeLoaded = nativeLoadMinecraftLibraries(nativeLibDir);
        if (!nativeLoaded) {
            throw new IllegalStateException("Gagal memuat libminecraftpe.so dari: " + nativeLibDir);
        }

        return new LoadedMinecraftEnv(
                pkgInfo.versionName,
                pkgInfo.getLongVersionCode(),
                nativeLibDir,
                allApkPaths,
                mcClassLoader,
                assetManager,
                mcResources
        );
    }
}
