package com.toolbox.mcpelauncher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.toolbox.mcpelauncher.bridge.ToolboxBridgeInstaller;
import com.toolbox.mcpelauncher.core.MinecraftPackageLoader;
import com.toolbox.mcpelauncher.overlay.ToolboxFloatingService;

public class MainActivity extends Activity {

    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0B1120"));
        root.setPadding(56, 40, 56, 40);
        root.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("🛠️ MCPE Toolbox Launcher v2.0 (Anti-Force Close)");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20f);
        root.addView(title);

        statusText = new TextView(this);
        statusText.setTextColor(Color.parseColor("#93C5FD"));
        statusText.setTextSize(13.5f);
        statusText.setPadding(0, 16, 0, 28);
        root.addView(statusText);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        Button btnOverlayPerm = createActionButton("🔑 1. Aktifkan Izin Overlay", "#0284C7");
        btnOverlayPerm.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivity(intent);
                Toast.makeText(this, "Aktifkan sakelar 'Tampilkan di atas aplikasi lain' untuk MCPE Toolbox!", Toast.LENGTH_LONG).show();
            } else {
                ToolboxBridgeInstaller.installOrUpdateBridgePack(this);
                startService(new Intent(this, ToolboxFloatingService.class));
                Toast.makeText(this, "Izin Overlay sudah aktif! Tombol 🛠️ TB sudah muncul di layar.", Toast.LENGTH_SHORT).show();
            }
        });

        Button btnLaunchMcpe = createActionButton("🚀 2. Buka Minecraft + Toolbox", "#10B981");
        btnLaunchMcpe.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Wajib klik tombol 1 (Aktifkan Izin Overlay) terlebih dahulu!", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivity(intent);
                return;
            }
            ToolboxBridgeInstaller.installOrUpdateBridgePack(this);
            startService(new Intent(this, ToolboxFloatingService.class));
            MinecraftPackageLoader.launchOfficialMinecraft(this);
        });

        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp1.rightMargin = 18;
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);

        btnRow.addView(btnOverlayPerm, lp1);
        btnRow.addView(btnLaunchMcpe, lp2);
        root.addView(btnRow);

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshMinecraftStatus();
    }

    private void refreshMinecraftStatus() {
        PackageInfo info = MinecraftPackageLoader.getInstalledMinecraftInfo(this);
        boolean overlayGranted = Settings.canDrawOverlays(this);
        String permStatus = overlayGranted
                ? "✅ Izin Floating Overlay: AKTIF (Siap Meluncur)"
                : "⚠️ Izin Floating Overlay: BELUM AKTIF (Klik Tombol 1 dulu)";

        if (info != null) {
            statusText.setText(
                    "✅ Minecraft Play Store Terdeteksi: v" + info.versionName +
                    " (Code: " + info.getLongVersionCode() + ")\n" +
                    permStatus + "\n" +
                    "🛡️ Mode Peluncuran: System Floating Overlay + Official MCPE Intent (100% Bebas Force Close & Aman Xbox Live)"
            );
        } else {
            statusText.setText(
                    "⚠️ Paket com.mojang.minecraftpe belum terdeteksi.\n" +
                    permStatus + "\n" +
                    "Pastikan Minecraft Bedrock sudah terinstal di HP kamu."
            );
        }
    }

    private Button createActionButton(String label, String hexColor) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13.5f);
        b.setAllCaps(false);
        b.setPadding(28, 24, 28, 24);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(hexColor));
        bg.setCornerRadius(18f);
        b.setBackground(bg);
        return b;
    }
}
