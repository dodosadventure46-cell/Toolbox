package com.toolbox.mcpelauncher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.toolbox.mcpelauncher.automation.ToolboxAutoService;
import com.toolbox.mcpelauncher.bridge.ToolboxBridgeInstaller;
import com.toolbox.mcpelauncher.bridge.ToolboxWebSocketServer;
import com.toolbox.mcpelauncher.core.MinecraftPackageLoader;
import com.toolbox.mcpelauncher.overlay.ToolboxFloatingService;

public class MainActivity extends Activity {

    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ToolboxWebSocketServer.getInstance().startServer();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0B1120"));
        root.setPadding(52, 36, 52, 36);
        root.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("🛠️ MCPE Toolbox Pro v3.0 — Direct Engine & Wi-Fi Combat");
        title.setTextColor(Color.WHITE);
        title.setTextSize(19f);
        root.addView(title);

        statusText = new TextView(this);
        statusText.setTextColor(Color.parseColor("#93C5FD"));
        statusText.setTextSize(13f);
        statusText.setPadding(0, 14, 0, 24);
        root.addView(statusText);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        Button btnOverlayPerm = createActionButton("🔑 1. Izin Floating Overlay", "#0284C7");
        btnOverlayPerm.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivity(intent);
            } else {
                startService(new Intent(this, ToolboxFloatingService.class));
                Toast.makeText(this, "Floating Overlay sudah aktif!", Toast.LENGTH_SHORT).show();
            }
        });

        Button btnCombatPerm = createActionButton("⚔️ 2. Aktifkan Kill Aura & Auto-Engine", "#BE123C");
        btnCombatPerm.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(intent);
            Toast.makeText(this, "Cari 'MCPE Toolbox Combat & Direct Engine' lalu nyalakan sakelarnya!", Toast.LENGTH_LONG).show();
        });

        Button btnLaunchMcpe = createActionButton("🚀 3. Buka Minecraft + Toolbox", "#10B981");
        btnLaunchMcpe.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Aktifkan dulu tombol 1 (Izin Floating Overlay)!", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivity(intent);
                return;
            }
            ToolboxBridgeInstaller.installOrUpdateBridgePack(this);
            startService(new Intent(this, ToolboxFloatingService.class));
            MinecraftPackageLoader.launchOfficialMinecraft(this);
        });

        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp1.rightMargin = 14;
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp2.rightMargin = 14;
        LinearLayout.LayoutParams lp3 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);

        btnRow.addView(btnOverlayPerm, lp1);
        btnRow.addView(btnCombatPerm, lp2);
        btnRow.addView(btnLaunchMcpe, lp3);
        root.addView(btnRow);

        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshMinecraftStatus();
    }

    private void refreshMinecraftStatus() {
        PackageInfo info = MinecraftPackageLoader.getInstalledMinecraftInfo(this);
        boolean overlayOk = Settings.canDrawOverlays(this);
        boolean combatOk = ToolboxAutoService.isServiceConnected();

        String s1 = overlayOk ? "✅ 1. Izin Floating Overlay: AKTIF" : "⚠️ 1. Izin Floating Overlay: BELUM AKTIF";
        String s2 = combatOk ? "✅ 2. Kill Aura & Auto-Engine Service: AKTIF" : "⚠️ 2. Kill Aura & Auto-Engine: Klik Tombol 2 untuk mengaktifkan";
        String s3 = "✅ 3. Direct Engine Server: ws://127.0.0.1:19131 (Aktif Otomatis) + Persistent Update Keystore";

        if (info != null) {
            statusText.setText(
                    "🎮 Minecraft Play Store: v" + info.versionName + " (" + info.getLongVersionCode() + ")\n" +
                    s1 + "\n" + s2 + "\n" + s3
            );
        } else {
            statusText.setText(
                    "⚠️ Paket com.mojang.minecraftpe belum terdeteksi.\n" +
                    s1 + "\n" + s2 + "\n" + s3
            );
        }
    }

    private Button createActionButton(String label, String hexColor) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12.5f);
        b.setAllCaps(false);
        b.setPadding(20, 22, 20, 22);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(hexColor));
        bg.setCornerRadius(16f);
        b.setBackground(bg);
        return b;
    }
}
