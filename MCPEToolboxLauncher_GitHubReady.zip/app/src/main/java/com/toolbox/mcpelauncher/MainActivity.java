package com.toolbox.mcpelauncher;

import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.toolbox.mcpelauncher.bridge.ToolboxBridgeInstaller;
import com.toolbox.mcpelauncher.core.MinecraftHostActivity;
import com.toolbox.mcpelauncher.core.MinecraftPackageLoader;

/**
 * Layar Dashboard Launcher:
 * - Mendeteksi otomatis versi Minecraft Bedrock (com.mojang.minecraftpe) dari Google Play Store
 * - Memasang jembatan otomatis Toolbox Script API (agar fitur Give Item/WorldBuilder bebas crash di semua versi)
 * - Meluncurkan MinecraftHostActivity dengan Floating Toolbox Overlay
 */
public class MainActivity extends AppCompatActivity {

    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#0B1120"));
        root.setPadding(64, 48, 64, 48);
        root.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("🛠️ MCPE Toolbox Wrapper Launcher");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22f);
        root.addView(title);

        statusText = new TextView(this);
        statusText.setTextColor(Color.parseColor("#93C5FD"));
        statusText.setTextSize(14f);
        statusText.setPadding(0, 20, 0, 32);
        root.addView(statusText);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        Button btnInstallBridge = createActionButton("📦 Sinkronkan Jembatan Versi Baru", "#0284C7");
        btnInstallBridge.setOnClickListener(v -> {
            requestStoragePermissionIfNeeded();
            boolean ok = ToolboxBridgeInstaller.installOrUpdateBridgePack(this);
            Toast.makeText(
                    this,
                    ok ? "Toolbox Bridge berhasil disinkronkan!" : "Gagal menyinkronkan Bridge, periksa izin penyimpanan.",
                    Toast.LENGTH_LONG
            ).show();
        });

        Button btnLaunch = createActionButton("🚀 Jalankan Minecraft + Toolbox", "#10B981");
        btnLaunch.setOnClickListener(v -> {
            PackageInfo info = MinecraftPackageLoader.getInstalledMinecraftInfo(this);
            if (info == null) {
                Toast.makeText(this, "Minecraft Bedrock (Google Play) belum terinstal!", Toast.LENGTH_LONG).show();
                return;
            }
            ToolboxBridgeInstaller.installOrUpdateBridgePack(this);
            startActivity(new Intent(this, MinecraftHostActivity.class));
        });

        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp1.rightMargin = 20;
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);

        btnRow.addView(btnInstallBridge, lp1);
        btnRow.addView(btnLaunch, lp2);
        root.addView(btnRow);

        setContentView(root);
        refreshMinecraftStatus();
    }

    private void refreshMinecraftStatus() {
        PackageInfo info = MinecraftPackageLoader.getInstalledMinecraftInfo(this);
        if (info != null) {
            statusText.setText(
                    "✅ Minecraft Play Store Terdeteksi: v" + info.versionName +
                    " (Code: " + info.getLongVersionCode() + ")
" +
                    "📂 Direktori Native: " + info.applicationInfo.nativeLibraryDir + "
" +
                    "🔄 Mode Kompatibilitas: Hybrid Dynamic Loader + ScriptEvent Bridge (Tahan Update Play Store)"
            );
        } else {
            statusText.setText(
                    "⚠️ Paket com.mojang.minecraftpe tidak ditemukan.
" +
                    "Pastikan Minecraft Bedrock resmi dari Google Play Store sudah terinstal di perangkat ini."
            );
        }
    }

    private void requestStoragePermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }

    private Button createActionButton(String label, String hexColor) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14f);
        b.setAllCaps(false);
        b.setPadding(32, 28, 32, 28);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor(hexColor));
        bg.setCornerRadius(18f);
        b.setBackground(bg);
        return b;
    }
}
