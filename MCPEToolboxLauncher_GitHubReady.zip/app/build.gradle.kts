plugins {
    id("com.android.application")
}

android {
    namespace = "com.toolbox.mcpelauncher"
    compileSdk = 34

    val envNdk = System.getenv("ANDROID_NDK_LATEST_HOME") ?: System.getenv("ANDROID_NDK_HOME")
    if (!envNdk.isNullOrEmpty() && file(envNdk).exists()) {
        ndkPath = envNdk
    }

    defaultConfig {
        applicationId = "com.toolbox.mcpelauncher"
        minSdk = 28
        targetSdk = 34
        versionCode = 103
        versionName = "1.0.3-PlayStoreSync"

        ndk {
            abiFilters += listOf("arm64-v8a")
        }

        externalNativeBuild {
            cmake {
                cppFlags += "-std=c++17 -O2 -fvisibility=hidden"
                arguments += "-DANDROID_STL=c++_shared"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug {
            isDebuggable = true
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    // Murni menggunakan Android SDK (android.app.Activity) agar bebas gagal unduh AAR dan kompilasi super cepat
}
