plugins {
    id("com.android.application")
}

android {
    namespace = "com.toolbox.mcpelauncher"
    compileSdk = 34

    signingConfigs {
        create("persistentConfig") {
            storeFile = file("toolbox_persistent.keystore")
            storePassword = "toolbox123"
            keyAlias = "toolbox_key"
            keyPassword = "toolbox123"
        }
    }

    defaultConfig {
        applicationId = "com.toolbox.mcpelauncher"
        minSdk = 28
        targetSdk = 34
        val runNum = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionCode = 300 + runNum
        versionName = "3.0." + runNum + "-Pro"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("persistentConfig")
        }
        debug {
            isDebuggable = true
            signingConfig = signingConfigs.getByName("persistentConfig")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
}
