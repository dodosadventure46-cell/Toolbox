plugins {
    id("com.android.application")
}

android {
    namespace = "com.toolbox.mcpelauncher"
    compileSdk = 35
    ndkVersion = "27.0.12077973"

    defaultConfig {
        applicationId = "com.toolbox.mcpelauncher"
        minSdk = 28
        targetSdk = 34
        versionCode = 100
        versionName = "1.0.0-PlayStoreSync"

        ndk {
            // Minecraft Bedrock Play Store terbaru wajib menggunakan arsitektur 64-bit ARM
            abiFilters += listOf("arm64-v8a")
        }

        externalNativeBuild {
            cmake {
                cppFlags += "-std=c++20 -O2 -fvisibility=hidden"
                arguments += "-DANDROID_STL=c++_shared"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    // Penting untuk kompatibilitas Minecraft Bedrock 1.21.80+ hingga versi Play Store terbaru (GameActivity)
    implementation("androidx.games:games-activity:3.0.5")
}
