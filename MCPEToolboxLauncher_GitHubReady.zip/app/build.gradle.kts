plugins {
    id("com.android.application")
}

android {
    namespace = "com.toolbox.mcpelauncher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.toolbox.mcpelauncher"
        minSdk = 28
        targetSdk = 34
        versionCode = 200
        versionName = "2.0.0-NoCrashOverlay"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug {
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
}
